/*
  ExArMo LabTest — dedicated motor-tester firmware  (v2.7.1)
  =========================================================
  [v2.7.1-R] Defaults corrected to the bead actually fitted: a 100k NTC, not
           a 10k one. The divider only ever reveals the RATIO R_ntc/R_fix, so
           0.30 V at room temperature was equally consistent with a 100k bead
           on 10k and a 10k bead on 1k — it took a meter on the part to tell
           them apart. Also adds 'X<degC>', which solves beta from one
           reference point, because beta is the number most likely to be wrong
           on an unmarked 100k bead and its error grows with temperature.
  [v2.7-R] MOTOR TEMPERATURE. A 100k NTC glass-bead thermistor on GPIO3 (PA2)
           is now read at 5 Hz and published as an 11th telemetry field, so
           "how hot did it get" stops being a separate Arduino on a separate
           serial port that has to be time-aligned afterwards. It also gives
           the thermal tests a temperature that belongs to the SAME timebase as
           Iq — the whole point of the Heat/Force and Thermal experiments.

           Wiring (divider, NTC on the HIGH side):
               3V3 ──[ NTC 100k ]── GPIO3/PA2 ──[ 10k 1% ]── GND
           so a HOT thermistor (falling resistance) reads a HIGHER voltage.
           At 25 C the node sits at 0.30 V; 40 C = 0.52 V, 55 C = 0.83 V,
           80 C = 1.45 V. See the long note at P_th_rfix for why the fixed leg
           is 10k and not the matched 100k the textbook divider rule asks for.
           Bead against the stator end-winding or the motor can, thermal paste
           or Kapton, and keep the two leads away from the phase wires — this
           is a high-impedance node next to 20 kHz PWM.

           WHY NOT analogRead(): stm32duino's analogRead() re-initialises the
           ADC peripheral on every call, and PA2 is on ADC1 — the same ADC
           SimpleFOC uses for injected low-side current sensing. It would
           silently reconfigure the current sense out from under the FOC loop.
           _readRegularADCVoltage() is the SimpleFOC helper that shares an ADC
           with injected conversions (it retries on HAL_BUSY), which is exactly
           how VSENS is already read at boot.

           The reading is range-checked at BOTH ends of the divider: an open
           lead and a shorted bead both produce a perfectly plausible-looking
           temperature if you only convert the maths, so flags bit5 reports
           whether the number is trustworthy and telemetry publishes 0 when it
           is not. An over-temperature trip ('Pj', default 85 C) drops the
           board to IDLE on its own — the bench GUI may be minimised, the
           operator may be elsewhere, and a stalled motor at 6 A does not wait.
           NOTE: 85 C is a BENCH limit, chosen so the Heat/Force test can run
           to its 80 C protection without the firmware pulling the plug first.
           The 40 C warn / 55 C stop thresholds for a limb in contact with the
           hardware belong to the REHAB firmware and GUI, not here.
  [v2.6-Q] HOLD gained an INTEGRAL term ('Pk'). A pure PD holds only by
           carrying a steady-state error (error = Iq/Kp), so the arm sagged
           further with every weight — 14 deg at 212 g — and the Kt fit then
           depended on a cos(tilt) correction. Raising Kp enough to hold that
           near level puts the loop back where it shook. The integrator removes
           the error instead of out-muscling it, so the arm returns to the same
           angle at every load and the geometry stops being a variable.
  [v2.5-O] HOLD shook violently once a healthy motor was fitted. Its gains are
           in A/rad, so real stiffness is Kp*Kt: the same Kp=25 that gave
           0.50 Nm/rad with the faulty motor gives 2.38 Nm/rad with a good one.
           The D term made it worse — encoder quantisation differentiated at
           1 kHz is 0.38 rad/s, which at Kd=0.8 injected 0.31 A of noise every
           tick. Gains lowered, D-term velocity filtered ('Pf'), and HOLD now
           ramps its authority in over 300 ms instead of grabbing.
  [v2.5-P] A single NaN reaching the host wedged the GUI's live readouts.
           Telemetry is now finite-checked at the source.
  [v2.4-N] 'A' reported success without the motor moving. alignSensor() skips
           its direction sweep when sensor_direction is already known and skips
           the offset capture when zero_electric_angle is already set — after
           the boot-time initFOC both are, so it did nothing and returned 1.
           doAlign() now clears both first. Also reports pp_check_result.
  [v2.3-M] "torque per amp is 5-8x too low, but perfectly linear" — the
           zero-electric-angle from initFOC is only valid if the shaft was FREE
           when it ran. Aligned against a loaded arm it is silently wrong, and
           because drive and measurement share the same wrong angle, Iq still
           tracks its setpoint and id still reads ~0 while real torque falls by
           cos(error). New 'A' command re-aligns on demand; 'L' now reports
           zero_electric_angle / sensor_direction / pole_pairs; 'Pz' and 'Pb'
           hard-code a known-good pair. NOTE: id ~ 0 does NOT prove the
           commutation angle is right.
  [v2.2-L] "jog at 0.01 A and it kicks hard" — the kick came from the CURRENT
           LOOP, not the setpoint. The DRV8301 needs ~1 ms to wake from
           EN_GATE; arm the FOC loop inside that window and it reads railed
           currents, sees a huge error against a ~0 A target, and slams
           voltage.q to the bus. Power-up is now staged: wake the bridge with
           the motor still disabled (60 ms blanking, ADC settles on valid
           samples), then enable, then ramp q/d voltage authority in from ~1 V
           over 200 ms. Nothing is commanded until armed.
  [v2.2-K] "and then it spins fast" — that one is my fault: v2.0 switched the
           speed governor off entirely. On a FREE shaft a torque command has
           nothing to push against, so it just accelerates. Replaced with a
           runaway CEILING at 20 rad/s ('Pv') that a real press (vel ~ 0)
           never feels, plus an independent trip at 2x that.
  [v2.1-J] "Iq reads -500 A in standby" — see the long note at the gate-driver
           power block in controlUpdate(). Short version: EN_GATE low puts the
           DRV8301 (shunt amplifiers included) in shutdown, and this board's
           sensing scale is 200 A PER VOLT, so the collapsed amplifier output
           read against the boot-time mid-rail offset renders as hundreds of
           phantom amps. IDLE now uses motor.disable() instead of
           driver.disable(), which stops loopFOC before the torque block, and
           telemetry publishes a hard 0 whenever the bridge is open.

  Bench firmware for the MKS XDrive Mini. SEPARATE from the ExArMo rehab
  firmware: no capstan scaling, no homing, no admittance — just clean
  primitives for motor characterisation, driven by ExarmoLabGui.py.

  Everything is MOTOR-SHAFT units (rad, rad/s, A).

  ---------------------------------------------------------------------------
  WHY v1.3 SHOWED NO Iq AND PUSHED NO FORCE  (all fixed here)
  ---------------------------------------------------------------------------
  [v2-A] WATCHDOG STARVATION — the real killer.
         v1.3 stamped last_rx_ms only from `if (Serial.available())` at the
         TOP of loop(), but command.run() at the BOTTOM of the same iteration
         drains the whole RX buffer. A 2-byte "K\n" that lands between those
         two points is eaten by command.run() and the top-of-loop check never
         sees it. Keepalives were therefore missed at random, the 3 s watchdog
         fired, state dropped to IDLE and the gate driver went HIGH-Z:
         iq_cmd = 0, measured Iq = 0, zero force on the load cell — silently.
         The ExArMo rehab firmware has NO watchdog, which is exactly why the
         same hardware "worked" there.
         FIX: every Commander callback feeds the watchdog (feed()). A command
         that PARSED is proof the host is alive. The Serial.available() stamp
         is kept as a bonus, not as the mechanism.

  [v2-B] THE APPROACH-SPEED GOVERNOR ZEROED THE COMMAND.
         v1.3 defaults were P_vcap = 0.15 rad/s (= 1.4 rpm!) and P_vgov = 8 A
         per rad/s of overspeed. Any shaft motion above 1.4 rpm collapsed the
         push current to zero within 0.02 rad/s. Taking up rope slack, backlash
         or a free-flight gap before the cell all exceed that instantly, so the
         arm crept at ~1.4 rpm with iq_cmd pinned at ~0 forever: no measured
         current (there was none to measure) and no force.
         FIX (revised in v2.2): the governor is gone. Gentle engagement is the
         GUI's contact detector's job, and runaway protection is a separate
         concern handled by the [v2.2-K] ceiling at 20 rad/s. One mechanism was
         being asked to do two unrelated jobs and did neither well.

  [v2-C] NO COMMAND DIRECTION SIGN.
         The rehab firmware has DIR_SIGN = -1 because +Iq moves the arm the
         "wrong" way on this rig. LabTest had no equivalent, so a positive C
         command could push the arm AWAY from the load cell: zero grams, and
         (with [v2-B]) zero current too. FIX: 'Ps<±1>' command direction, and
         the GUI has a direction toggle + jog to verify it in 5 seconds.

  [v2-D] NO WAY TO TELL A DEAD CURRENT SENSE FROM A ZERO COMMAND.
         Telemetry carried iq_meas and iq_cmd only. Now it also carries id,
         voltage.q and a health/flags word, and the firmware itself raises
         EV,SENSEFAIL when it is commanding real current and measuring none.

  [v2-E] BOOT-TIME MOTOR CHARACTERISATION WAS RUNNING BY ACCIDENT.
         tuneCurrentController() falls back to characteriseMotor() whenever
         phase inductance is unset — which it was. That injects voltage into
         the motor at boot, takes seconds, OVERWRITES phase_resistance, and
         quietly leaves the default current-PID gains if it fails. Nothing
         about the resulting tuning was reproducible between the rehab rig and
         the bench rig. FIX: phase inductance is now set explicitly ('Pl'), so
         tuning is deterministic and boot is silent. 'Pn<bw>' re-tunes live.

  [v2-F] Vbus SANITY GUARD.
         driver.voltage_limit was set straight from the VSENS ADC read. A bad
         read (0 V) silently caps every phase voltage at zero: no torque, no
         current, no error. Now guarded, announced, and overridable ('Pu').

  [v2-G] CURRENT-PID WINDUP ACROSS IDLE.
         loopFOC keeps running while the gate driver is HIGH-Z, so the q/d PIDs
         integrate against a driver that cannot respond. PIDs are now reset on
         every transition back to powered.

  [v2-H] MEASURED-Iq SIGN AUTO-CALIBRATION (ported from rehab v2.3).
         With current_sense.skip_align = true the polarity of the measured
         q-current is unverified. While pushing a known current the firmware
         now correlates commanded vs measured and sets P_iq_sign itself.

  [v2-I] motor.monitor() CONFIGURED LIKE THE REHAB FIRMWARE.
         _MON_CURR_Q | _MON_ANGLE, ',' separator, 'M' start/end char. This
         lets you point the KNOWN-GOOD simplefoc_loadcell_gui.py at this board
         (send MMS0001001 then MMD10) as an independent cross-check of the
         'D,' telemetry. Note monitor() prints current in mA.

  ---------------------------------------------------------------------------
  Modes (telemetry state field):
    0 IDLE  — gate driver HIGH-Z: shaft is truly free (rotate arm by hand)
    1 VEL   — SimpleFOC velocity loop            ('V<rad/s>')   → KV back-EMF
    2 HOLD  — PD position hold at the angle where 'H' was sent  → KT by weights
    3 CURR  — direct Iq command                  ('C<A>')       → KT loadcell /
                                                                  heat / capstan
  Safety:
    - Iq hard-clamped to P_iq_lim ('Pi', default 6 A) in every mode
    - serial watchdog: in HOLD/CURR, P_wd_ms without ANY parsed command → IDLE
      (GUI sends 'K' keepalives at 2 Hz; 'Pt0' disables the watchdog)
    - 'O0' (or 'S') from anywhere → IDLE, targets zeroed, driver released

  Commands (Commander, newline-terminated, params WITHOUT space e.g. Pi4):
    V<f>   velocity mode, target [rad/s motor]      (updates live)
    H      hold the CURRENT shaft angle (PD)
    C<f>   current mode, target Iq [A], slew-ramped at 'Pr' A/s
    O0 / S stop → IDLE (freewheel)
    D<n>   telemetry every n ms (0 = off)
    K      keepalive (no-op, feeds the watchdog)
    L      status dump         Z    current-sense self-test (1 s, needs a load)
    A      re-align sensor now (IDLE + shaft FREE) -> EV,ALIGN,ok,zea,dir
    P i<f> Iq limit [A]        P p<f> hold Kp [A/rad]   P d<f> hold Kd [A·s/rad]
    P q<f> measured-Iq sign    P s<f> COMMAND direction sign (±1)
    P f<f> LPF on the HOLD D-term [s]    P k<f> HOLD integral gain [A/(rad·s)]
    P r<f> Iq slew rate [A/s]  P c<f> CURR velocity damping [A·s/rad]
    P v<f> runaway ceiling [rad/s], 0 = OFF
    P m<n> torque mode 0 volt / 1 dc_current / 2 foc_current
    P t<n> watchdog [ms], 0 = off        P a<n> Iq-sign auto-cal 0/1
    P l<f> phase inductance [H]          P n<f> retune current PI at <f> Hz
    P u<f> Vbus override [V]             P w<f> phase resistance [ohm]
    P z<f> zero_electric_angle [rad]     P b<n> sensor direction (+1/-1)
    P j<f> over-temp trip [C], 0 = OFF   P e<f> thermistor beta [K]    [v2.7-R]
    P h<f> thermistor R25 [ohm]          P o<f> divider resistor [ohm] [v2.7-R]
    P y<f> temperature offset [C]        T      one-shot temperature dump
    X<degC> solve beta from a reference temperature (use a 60-80 C bath;
            refused within 10 C of 25 C, where the equation is singular)
    M...   SimpleFOC motor passthrough (MMS0001001 / MMD10 = monitor on)

  Telemetry (CSV, 921600 baud) — 11 fields:
    D,t_ms,state,angle_rad,vel_rads,iq_meas,iq_cmd,id_meas,vq,flags,temp_C
    flags bit0 foc_ready · bit1 motor.enabled · bit2 FOC armed (driving)
          bit3 current-sense healthy · bit4 Vbus ok · bit5 thermistor ok
    temp_C is 0 whenever bit5 is clear — an unread sensor must never look like
    a cold motor, so read the FLAG, not the number.

  Events:
    EV,BOOT,<ver>  EV,STATE,<n>  EV,WATCHDOG  EV,FOCFAIL  EV,VBUS,<v>
    EV,SENSEFAIL,<iq_cmd>,<iq_meas>   EV,IQSIGN,<±1>   EV,SELFTEST,<cmd>,<meas>
    EV,RUNAWAY,<vel>
    EV,TEMP,<C>            over-temp trip — the board has gone to IDLE
    EV,TEMPFAIL,<volts>    thermistor open / shorted / out of range
    EV,TEMPOK,<C>          the thermistor came back
    EV,CALBETA,<B>,...     beta solved from an 'X' reference point
*/
#include <Arduino.h>
#include <SimpleFOC.h>
#include "current_sense/hardware_specific/stm32/stm32_adc_utils.h"
#include "SimpleFOCDrivers.h"
#include "comms/can/CANCommander.h"
#include "SimpleCANio.h"

#define FW_VERSION "EXARMO-LABTEST-2.7.1"

// ======================= pinout (same board as ExArMo) ============
#define M0_INH_A PA8
#define M0_INH_B PA9
#define M0_INH_C PA10
#define M0_INL_A PB13
#define M0_INL_B PB14
#define M0_INL_C PB15
#define EN_GATE  PB12
#define M0_IB PC0
#define M0_IC PC1
#define SPI3_SCL  PC10
#define SPI3_MISO PC11
#define SPI3_MOSI PC12
#define AS5047_CS PA15
#define M0_nCS    PC13
#define VSENS  PA6
#define VSCALE 19.0f
#define CAN0_RX PB_8
#define CAN0_TX PB_9
// [v2.7-R] motor thermistor. GPIO3 on the MKS XDrive Mini's ODrive-3.6-style
// header is PA2 (ADC123_IN2), which nothing else on this board uses. If you
// land the bead on a different pin it MUST be ADC-capable and free: PA0, PA1,
// PA3, PA5, PA7, PB0, PB1, PC2..PC5 all qualify here. PA4 does NOT — it is
// ADC-capable but shares SPI1; PA15 is the AS5047P chip select; PC0/PC1 are
// the phase-B/C shunts; PA6 is VSENS.
#define THERM_PIN  PA2
#define THERM_VREF 3.3f

// ======================= parameters ===============================
volatile float P_iq_lim  = 6.0f;    // [A] absolute Iq clamp ('Pi')
// [v2.5-O] HOLD gains are in AMPS per radian, so their real stiffness is
// Kp * Kt — which means they were silently tuned around whatever motor was
// fitted. With the faulty motor (Kt 20 mNm/A) Kp=25 gave 0.50 Nm/rad; with a
// healthy one (Kt 95) the same number gives 2.38 Nm/rad, nearly 5x the loop
// gain. That is why HOLD started shaking the moment the motor was swapped.
// Defaults dropped accordingly; tune upward from here, not down.
volatile float P_Kp_hold = 8.0f;    // [A/rad] hold stiffness ('Pp')
volatile float P_Kd_hold = 0.2f;    // [A s/rad] hold damping ('Pd')
// The D term is the other half of the shake. The AS5047P resolves 3.8e-4 rad,
// so velocity differentiated at 1 kHz is quantised to 0.38 rad/s — at the old
// Kd that injected 0.31 A of pure noise on EVERY tick (29 mNm of torque noise
// with a good motor). Filter the velocity the D term sees.
volatile float P_hold_tf = 0.010f;  // [s] LPF on the hold D-term ('Pf')
// [v2.6-Q] INTEGRAL term for HOLD. A pure PD holds position only by carrying a
// steady-state error — error = Iq/Kp — so the arm sags further with every
// weight added, and the Kt measurement then needs a cos(tilt) correction that
// is only as good as its horizontal reference. Raising Kp enough to hold
// 200 g+ near level puts the loop back where it shook. An integrator removes
// the error instead of out-muscling it: the arm returns to the SAME angle at
// every load, so the geometry stops being a variable at all.
volatile float P_Ki_hold = 15.0f;   // [A/(rad·s)] hold integral gain ('Pk')
static float   hold_integ = 0.0f;
static float   hold_vel_f = 0.0f;
static uint32_t hold_tick = 0;
static const uint32_t HOLD_RAMP_TICKS = 300;   // [ms] soft engage
volatile float P_iq_sign = 1.0f;    // MEASURED-Iq polarity ('Pq')
// [v2-C] COMMAND direction. The rehab firmware needs DIR_SIGN = -1 on this
// rig; whether the bench fixture needs it too depends on how the arm is
// clamped. Set it once with 'Ps-1' / 'Ps1' after a jog test.
volatile float P_dir     = 1.0f;
// current-mode shaping
volatile float P_iq_ramp = 2.0f;    // [A/s] slew limit on the Iq target ('Pr')
volatile float P_Kd_curr = 0.05f;   // [A·s/rad] velocity damping in CURR ('Pc')
// [v2.2-K] RUNAWAY CEILING — not the old "approach governor".
// A torque command on a FREE shaft has nothing opposing it but friction, so
// the motor just keeps accelerating: 0.01 A still winds up to a scary speed
// given a couple of seconds. v1.3's governor caught that by accident, but at
// 0.15 rad/s (1.4 rpm) it also strangled every real press. This is the same
// idea set where it belongs: a ceiling high enough that a genuine press (which
// sits at vel ~ 0) never feels it, low enough that a free shaft cannot run
// away. Command tapers to zero between P_vmax and 1.25*P_vmax. 'Pv0' disables.
volatile float P_vmax    = 20.0f;   // [rad/s] runaway ceiling (~190 rpm) ('Pv')
static float   iq_now    = 0.0f;    // slewed current state
// [v2.2-L] staged power-up. See the long note in controlUpdate().
static const uint32_t POWER_BLANK_TICKS = 60;    // [ms] DRV8301 wake-up blanking
static const uint32_t VQ_RAMP_TICKS     = 200;   // [ms] q-voltage authority ramp
// [v2-A] watchdog period, ms. 0 disables it entirely ('Pt').
volatile uint32_t P_wd_ms = 3000;
// [v2-H] measured-Iq sign auto-calibration on/off ('Pa')
volatile uint8_t P_iqcal_en = 1;
// [v2-E] electrical parameters — set EXPLICITLY so tuneCurrentController()
// never falls back to characteriseMotor() (which injects voltage at boot,
// overwrites R, and is not reproducible between rigs).
volatile float P_R = 0.54f;         // [ohm] phase resistance ('Pw')
volatile float P_L = 0.00025f;      // [H]  phase inductance  ('Pl')
volatile float P_bw = 100.0f;       // [Hz] current-loop bandwidth ('Pn')
volatile float P_vbus_override = 0.0f;  // [V] 0 = use the VSENS measurement ('Pu')

// [v2.7.1-R] thermistor: 100k glass-bead NTC (B25/50 = 3950 K) against a
// 10k 1% divider resistor to ground. Everything is a parameter because the
// bead is the component on this bench most likely to be swapped for whatever
// is in the drawer.
//
// WHY 10k FIXED AGAINST A 100k BEAD, rather than the matched 100k that the
// textbook divider rule asks for. The rule optimises sensitivity at 25 C,
// which is not where this instrument works — the band that matters is 40-85 C.
// Measured in ADC counts per degree (12-bit, 3.3 V):
//
//        T      R_ntc     v(10k fix)  LSB/degC      v(100k fix)  LSB/degC
//      25 C    100.0k      0.300 V      15            1.650 V      45
//      40 C     53.0k      0.524 V      22            2.157 V      37
//      55 C     29.8k      0.830 V      28            2.543 V      26
//      80 C     12.7k      1.454 V      32            2.928 V      13
//
// The matched divider is better cold and WORSE hot; they cross at about 45 C.
// Both are far past the point where quantisation matters (>10 counts/degC is
// under 0.1 C), so sensitivity is not the deciding factor — source impedance
// is. A 100k/100k divider presents 50 kohm to the ADC, which is too high for
// the STM32's sample-and-hold at the sample time SimpleFOC configures, and
// reads a few percent low in a way that looks exactly like a calibration
// error. The 10k leg keeps the node under 9.1 kohm at room temperature and
// falling as the motor heats. Keep the 10k.
//
// Consequence to know: at 25 C the node is only 0.30 V, six times the 0.05 V
// fault floor, and the floor starts rejecting below about -12 C. That is not
// a temperature this motor will ever be, so the fault detector still only
// fires on real wiring faults.
volatile float P_th_rfix = 10000.0f;   // [ohm] divider resistor to GND ('Po')
volatile float P_th_r25  = 100000.0f;  // [ohm] NTC nominal at 25 C     ('Ph')
// BETA IS THE LEAST TRUSTWORTHY NUMBER HERE. 3950 is right for most generic
// beads, but 100k parts vary more than 10k ones: a Semitec 104GT-type is
// B ~ 4267, and running that part on 3950 reads 63.2 C when it is really
// 60.0 C — an error that grows with temperature, so it is worst exactly where
// the over-temp decision is made. If the part has no datasheet, calibrate it
// with the 'X' command against a reference thermometer (see doCalBeta).
volatile float P_th_beta = 3950.0f;   // [K]   beta constant           ('Pe')
volatile float P_th_off  = 0.0f;      // [C]   offset vs a reference   ('Py')
// Over-temperature trip. BENCH value: the Heat/Force experiment deliberately
// runs to its own 80 C software protection, so a firmware trip below that
// would abort every thermal run and look like a fault. The rehab firmware
// wants something far lower — a limb is touching that hardware.
volatile float P_temp_trip = 85.0f;   // [C] 0 = OFF ('Pj')
static const float TEMP_TRIP_HYST = 5.0f;   // [C] must cool this far to re-arm

// ======================= state ====================================
enum LState : uint8_t { L_IDLE=0, L_VEL, L_HOLD, L_CURR };
volatile LState state = L_IDLE;
volatile float vel_target = 0.0f;   // [rad/s]
volatile float iq_target  = 0.0f;   // [A]
float hold_angle = 0.0f;            // [rad] captured on 'H'

volatile float s_ang=0, s_vel=0, s_iqm=0, s_iqc=0, s_idm=0, s_vq=0;
volatile uint32_t last_rx_ms = 0;   // watchdog
bool  foc_ready = false;            // initFOC succeeded — motor can move
bool  vbus_ok   = false;
float vbus = 0.0f;

// event queue (Serial inside the ISR is unsafe — flags set here, printed in loop)
volatile bool ev_watchdog = false;
volatile bool ev_sensefail = false;
volatile bool ev_state = false;
volatile bool ev_iqsign = false;
volatile bool ev_runaway = false;
volatile float ev_a = 0, ev_b = 0;

// [v2.7-R] thermistor state. temp_ok is the ONLY thing that says whether
// temp_c means anything: an open lead reads as a cold motor and a shorted bead
// reads as a hot one, and both convert without complaint.
volatile float temp_c   = 0.0f;     // [C] filtered, valid only while temp_ok
volatile bool  temp_ok  = false;
static bool    temp_seeded  = false;   // first good sample initialises the LPF
static bool    temp_tripped = false;   // latched until it cools by the hyst
static bool    temp_fault_said = false;// so a missing bead says so once, not at 5 Hz
static uint32_t temp_last_ms = 0;
volatile bool ev_temptrip = false, ev_tempfail = false, ev_tempok = false;
volatile float ev_t = 0;

// [v2.2-L] staged power-up state
static uint32_t ltick      = 0;      // control ticks since boot (1 ms each)
static uint32_t power_tick = 0;      // tick at which the bridge was woken
static bool     armed      = false;  // true once the FOC loop may drive torque
static uint32_t runaway_ticks = 0;

// [v2-D] current-sense health monitor
static uint32_t sense_bad_ticks = 0;
volatile bool sense_ok = true;

// [v2-H] measured-Iq sign auto-calibration
static float    iqcal_acc = 0.0f;
static uint32_t iqcal_n   = 0;
static bool     iqcal_done = false;

// [v2] self-test ('Z')
volatile uint8_t selftest = 0;      // 0 off, 1 running
static uint32_t  selftest_tick = 0;
static float     selftest_acc_cmd = 0, selftest_acc_meas = 0;
static uint32_t  selftest_n = 0;

// ======================= SimpleFOC objects ========================
BLDCMotor motor = BLDCMotor(7);
BLDCDriver6PWM driver = BLDCDriver6PWM(M0_INH_A,M0_INL_A, M0_INH_B,M0_INL_B, M0_INH_C,M0_INL_C, EN_GATE);
LowsideCurrentSense current_sense = LowsideCurrentSense(0.0005f, 10.0f, _NC, M0_IB, M0_IC);
MagneticSensorSPI sensor = MagneticSensorSPI(AS5047_SPI, AS5047_CS, 10000000);
SPIClass SPI_3(SPI3_MOSI, SPI3_MISO, SPI3_SCL);
Commander command = Commander(Serial);
CANio can(CAN0_RX, CAN0_TX);
CANCommander commandc(can, 15);
HardwareTimer* ctrl_timer = nullptr;   // [v2.3-M] so 'A' can pause the ISR

static const float FOC_HZ  = 20000.0f;
static const int   CTRL_DIV = 20;             // control loop = 1 kHz
static const float DT = CTRL_DIV / FOC_HZ;    // 1 ms
static inline float clampf(float v, float lo, float hi){ return v<lo?lo:(v>hi?hi:v); }
// [v2.5-P] One NaN reaching the host is enough to wedge the GUI: Serial.print
// emits "nan"/"ovf", Python's float() accepts both, and the value then poisons
// every plot and average downstream. Never let a non-finite number leave the
// board — publish 0 and say so.
volatile bool ev_nonfinite = false;
static inline float safef(float v){
  if (isfinite(v)) return v;
  ev_nonfinite = true;
  return 0.0f;
}

// [v2-A] THE watchdog fix: any command that parsed is proof the host is alive.
static inline void feed(){ last_rx_ms = millis(); }

static inline void setState(LState s){
  if (state != s){ state = s; ev_state = true; }
}

// ======================= [v2.7-R] thermistor ======================
// Called from loop() at 5 Hz — NOT from the 1 kHz control ISR. The regular
// conversion shares ADC1 with the injected low-side current sampling and
// _readRegularADCVoltage() polls (with retries) until the ADC is free; that is
// harmless five times a second and unacceptable inside the FOC loop.
//
// Divider, NTC on the high side:   3V3 ─[NTC]─ PA2 ─[R_fix]─ GND
//   v   = VREF * R_fix / (R_ntc + R_fix)
//   R_ntc = R_fix * (VREF/v - 1)
//   1/T = 1/298.15 + ln(R_ntc/R25)/beta        (beta model, Kelvin)
//
// Both rails are rejected before any of that runs. A disconnected bead pulls
// the node to 0 V, which the maths happily turns into "very cold"; a shorted
// one pulls it to 3V3 and reads "very hot". Neither is a temperature, and a
// thermal experiment that silently logs one is worse than one that stops.
static void thermUpdate(){
  float v = _readRegularADCVoltage(THERM_PIN);
  bool good = isfinite(v) && v > 0.05f && v < (THERM_VREF - 0.05f);
  float t = 0.0f;
  if (good){
    float r_ntc = P_th_rfix * (THERM_VREF / v - 1.0f);
    if (r_ntc > 1.0f && isfinite(r_ntc)){
      float inv = 1.0f / 298.15f + logf(r_ntc / P_th_r25) / P_th_beta;
      t = (inv > 1e-6f) ? (1.0f / inv - 273.15f + P_th_off) : 0.0f;
      // a plausible reading is still not a plausible MOTOR reading
      good = isfinite(t) && t > -40.0f && t < 200.0f;
    } else good = false;
  }

  if (!good){
    // Announce ONCE per fault, not five times a second. A board with no bead
    // fitted is a normal way to run a KV or Kt test, and a console that scrolls
    // a fault at 5 Hz is a console nobody reads.
    if (!temp_fault_said){ temp_fault_said = true; ev_tempfail = true; ev_t = v; }
    temp_ok = false; temp_seeded = false; temp_c = 0.0f;
    return;
  }
  temp_fault_said = false;

  if (!temp_seeded){ temp_c = t; temp_seeded = true; ev_tempok = true; ev_t = t; }
  else             { temp_c += 0.25f * (t - temp_c); }   // ~0.8 s at 5 Hz
  temp_ok = true;

  // ---- over-temperature trip ----
  // Latched, with hysteresis: without it a motor sitting exactly on the limit
  // toggles IDLE/CURRENT a few times a second, which reads as a flapping link
  // rather than as the thermal limit it is.
  if (P_temp_trip > 0.0f){
    if (!temp_tripped && temp_c >= P_temp_trip){
      temp_tripped = true;
      setState(L_IDLE); iq_target = 0; vel_target = 0; iq_now = 0;
      selftest = 0; selftest_tick = 0;
      ev_temptrip = true; ev_t = temp_c;
    } else if (temp_tripped && temp_c < P_temp_trip - TEMP_TRIP_HYST){
      temp_tripped = false;
    }
  } else {
    temp_tripped = false;
  }
}

// ======================= control loop (1 kHz) =====================
void controlUpdate(){
  float ang = motor.shaft_angle;
  float vel = motor.shaft_velocity;
  float iq_raw = motor.current.q;
  ltick++;

  // ================= [v2.2-L] STAGED POWER-UP =========================
  // This block runs FIRST, before any torque is computed, because whether the
  // bridge may drive at all decides what the command is allowed to be.
  //
  // The problem it solves: "jog at 0.01 A and the motor kicks hard".
  // The DRV8301 does not wake instantly from EN_GATE — its shunt amplifiers
  // need roughly a millisecond to come up. Enable the FOC loop in that window
  // and it reads railed currents (200 A per volt on this board, see [v2.1-J]),
  // computes an enormous error against a ~0 A setpoint, and slams voltage.q to
  // the bus limit. 24 V across 0.54 ohm is not a 0.01 A jog — it is a punch,
  // and it lands before any feedback exists to stop it. The commanded current
  // is irrelevant; the kick comes from the CURRENT LOOP, not the setpoint.
  //
  // So power-up is now staged:
  //   1. driver.enable()      — wake the DRV8301, motor still DISABLED, so
  //                             loopFOC returns early and drives nothing.
  //                             PWM sits at 0,0,0 (low sides on), which is
  //                             exactly the conduction state the boot-time
  //                             offset calibration assumed — the ADC settles
  //                             on valid zero-current samples during blanking.
  //   2. after POWER_BLANK_TICKS — motor.enable(): PIDs reset, loop live.
  //   3. for VQ_RAMP_TICKS    — q/d voltage authority ramps in from ~1 V, so
  //                             even if something IS wrong with the feedback,
  //                             the worst case is a nudge and not a lunge.
  bool want_power = (state != L_IDLE) || selftest;
  static bool powered = true;
  if (want_power != powered){
    powered = want_power;
    if (powered){
      driver.enable();                    // stage 1: wake only, do NOT arm
      power_tick = ltick;
      armed = false;
    } else {
      motor.disable();                    // clears `enabled` — see [v2.1-J]
      armed = false;
      motor.PID_current_q.limit = motor.voltage_limit;
      motor.PID_current_d.limit = motor.voltage_limit;
    }
  }
  if (powered && !armed && (ltick - power_tick) >= POWER_BLANK_TICKS){
    motor.PID_current_q.limit = 1.0f;     // stage 3 starts at a whisper
    motor.PID_current_d.limit = 1.0f;
    motor.enable();                       // stage 2: resets both current PIDs
    armed = true;
  }
  if (powered && armed){
    uint32_t since = ltick - power_tick - POWER_BLANK_TICKS;
    if (since <= VQ_RAMP_TICKS){
      float f = (float)since / (float)VQ_RAMP_TICKS;
      float lim = 1.0f + f * (motor.voltage_limit - 1.0f);
      motor.PID_current_q.limit = lim;
      motor.PID_current_d.limit = lim;
    }
  }

  // ---- serial watchdog (never keep pushing torque with a dead host) ----
  if (P_wd_ms > 0 && (state == L_HOLD || state == L_CURR) &&
      (millis() - last_rx_ms > P_wd_ms)){
    setState(L_IDLE); iq_target = 0; vel_target = 0; iq_now = 0;
    selftest = 0; selftest_tick = 0;      // a silent host aborts the self-test too
    ev_watchdog = true;
  }

  // ---- [v2.7-R] over-temperature latch, enforced every tick ----
  // thermUpdate() sets the latch at 5 Hz and the Commander refuses new motion
  // commands while it is set; this is the third net, and the only one that
  // runs in the control loop itself.
  if (temp_tripped && state != L_IDLE){
    setState(L_IDLE); iq_target = 0; vel_target = 0; iq_now = 0;
    selftest = 0; selftest_tick = 0;
  }

  float iq_cmd = 0.0f;

  // ---- self-test overrides everything: 1 s of a known 1 A push ----
  if (selftest){
    if (selftest_tick == 0) { iq_now = 0; }
    selftest_tick++;
    float ramp = clampf(selftest_tick / 200.0f, 0.0f, 1.0f);   // 200 ms ramp-in
    iq_cmd = P_dir * 1.0f * ramp;
    if (selftest_tick > 300){                 // average over the last 700 ms
      selftest_acc_cmd  += fabsf(iq_cmd);
      selftest_acc_meas += fabsf(iq_raw);
      selftest_n++;
    }
    if (selftest_tick > 1000){
      ev_a = selftest_n ? selftest_acc_cmd / selftest_n : 0.0f;
      ev_b = selftest_n ? selftest_acc_meas / selftest_n : 0.0f;
      selftest = 2;                            // loop() prints and clears
      iq_cmd = 0;
    }
  } else {
    switch(state){
      case L_HOLD: {
        // [v2.5-O] soft engage: ramp authority in over HOLD_RAMP_TICKS rather
        // than applying full stiffness against whatever error exists the
        // instant 'H' lands — the arm sags during the 60 ms power-up blanking,
        // so that error is never zero and full gain against it is a lurch.
        float f = clampf((ltick - hold_tick) / (float)HOLD_RAMP_TICKS, 0.0f, 1.0f);
        // filtered velocity for the D term (see the P_hold_tf note above)
        float a = clampf(DT / fmaxf(P_hold_tf, DT), 0.0f, 1.0f);
        hold_vel_f += a * (vel - hold_vel_f);
        float e = hold_angle - ang;
        // integrate only once authority has ramped in, and clamp to the same
        // budget as the output so it can never wind up beyond what the motor
        // is allowed to deliver
        if (f > 0.99f) hold_integ = clampf(hold_integ + P_Ki_hold * e * DT,
                                           -P_iq_lim, P_iq_lim);
        iq_cmd = P_dir * f * clampf(P_Kp_hold*e + hold_integ
                                    - P_Kd_hold*hold_vel_f,
                                    -P_iq_lim, P_iq_lim);
        break; }

      case L_CURR: {
        // slew the target: a torque STEP into a springy loadcell is an impulse
        float tgt = clampf(iq_target, -P_iq_lim, P_iq_lim);
        float dstep = P_iq_ramp * DT;
        float d = tgt - iq_now;
        if      (d >  dstep) iq_now += dstep;
        else if (d < -dstep) iq_now -= dstep;
        else                 iq_now  = tgt;

        float iq_g = iq_now;
        // [v2.2-K] runaway ceiling. Symmetric in |vel| and it only ever
        // REDUCES the push toward zero — it never reverses, so it cannot
        // oscillate the way v1.3's directional governor did at stall. A real
        // press sits at vel ~ 0 and never touches this.
        if (P_vmax > 0.0f){
          float over = fabsf(vel) - P_vmax;
          if (over > 0.0f)
            iq_g = iq_now * clampf(1.0f - over / (0.25f * P_vmax), 0.0f, 1.0f);
        }
        // light velocity damping absorbs contact bounce. At stall vel ~ 0,
        // so the force reading is unbiased.
        iq_cmd = P_dir * clampf(iq_g - P_Kd_curr * vel, -P_iq_lim, P_iq_lim);
        break; }

      default: break;               // L_IDLE, L_VEL handled below
    }
  }

  // [v2.2-L] nothing may be commanded until the bridge is awake AND armed
  if (!armed) iq_cmd = 0.0f;

  // [v2.2-K] hard runaway trip: the taper above should make this unreachable,
  // but a torque command into a free shaft is the one thing on this bench that
  // can hurt someone, so it gets a second, independent net.
  if (armed && P_vmax > 0.0f && state != L_VEL && !selftest &&
      fabsf(vel) > 2.0f * P_vmax){
    if (++runaway_ticks > 300){
      runaway_ticks = 0;
      setState(L_IDLE); iq_target = 0; iq_now = 0; iq_cmd = 0;
      ev_runaway = true; ev_a = vel;
    }
  } else {
    runaway_ticks = 0;
  }

  if (state == L_VEL && !selftest){
    motor.move(armed ? clampf(vel_target, -300.0f, 300.0f) : 0.0f);
    iq_cmd = 0;
  } else {
    iq_cmd = clampf(iq_cmd, -P_iq_lim, P_iq_lim);
    motor.move(iq_cmd);
  }

  // ---- [v2-D] current-sense health: commanding real current, measuring none?
  if (armed && fabsf(iq_cmd) > 0.3f){
    if (fabsf(iq_raw) < 0.15f * fabsf(iq_cmd)) sense_bad_ticks++;
    else                                       sense_bad_ticks = 0;
    if (sense_bad_ticks > 1000){                 // 1 s of commanded-but-unseen
      sense_bad_ticks = 0;
      if (sense_ok){ sense_ok = false; ev_sensefail = true;
                     ev_a = iq_cmd; ev_b = iq_raw; }
    }
  } else {
    sense_bad_ticks = 0;
    if (fabsf(iq_cmd) < 0.05f) sense_ok = true;   // re-arm when idle
  }

  // ---- [v2-H] measured-Iq sign auto-calibration ----
  if (P_iqcal_en && !iqcal_done && armed && fabsf(iq_cmd) > 0.3f){
    iqcal_acc += iq_cmd * iq_raw;
    if (++iqcal_n > 500){
      float s = (iqcal_acc >= 0.0f) ? 1.0f : -1.0f;
      if (fabsf(iqcal_acc) > 1e-3f){
        iqcal_done = true;
        if (s != P_iq_sign){ P_iq_sign = s; ev_iqsign = true; }
      }
      iqcal_acc = 0; iqcal_n = 0;
    }
  }

  // [v2.1-J] With the bridge open, current is not merely unknown — it is
  // provably zero. Publish 0 rather than a frozen last-reading, so nothing
  // stale ever reaches the GUI's averages, plots or Kt fits.
  s_ang = safef(ang); s_vel = safef(vel);
  s_iqm = armed ? safef(P_iq_sign * iq_raw) : 0.0f;
  s_idm = armed ? safef(motor.current.d)    : 0.0f;
  s_vq  = armed ? safef(motor.voltage.q)    : 0.0f;
  s_iqc = safef(iq_cmd);
}

// ======================= commander ================================
// [v2.7-R] A trip that only fires once is not a limit. Without this, the
// operator (or the GUI's retry) can send 'C2' straight after an over-temp stop
// and the motor runs hot again — the trip cannot fire a second time until it
// has cooled past the hysteresis, so nothing would stop it.
static inline bool tempBlocked(){
  if (!temp_tripped) return false;
  Serial.print(F("EV,TEMP,")); Serial.println(temp_c, 1);
  Serial.print(F("EV,MSG,over-temperature - cool below "));
  Serial.print(P_temp_trip - TEMP_TRIP_HYST, 1);
  Serial.println(F("C before commanding torque"));
  return true;
}

void doMotor(char* cmd){ feed(); command.motor(&motor, cmd); }
void doKeep (char* cmd){ (void)cmd; feed(); }          // watchdog food

void doStop_(){
  setState(L_IDLE); vel_target = 0; iq_target = 0; iq_now = 0;
  selftest = 0; selftest_tick = 0;
  motor.controller = MotionControlType::torque;
  Serial.println(F("ACK,STOP"));
}
void doMode (char* cmd){ (void)cmd; feed(); doStop_(); }   // O0 (any O -> stop)
void doStopS(char* cmd){ (void)cmd; feed(); doStop_(); }   // S

void doVel(char* cmd){
  feed();
  if (tempBlocked()) return;
  vel_target = clampf(atof(cmd), -300.0f, 300.0f);
  Serial.print(F("ACK,V,")); Serial.println(vel_target, 2);
  if (state != L_VEL){
    motor.controller = MotionControlType::velocity;
    setState(L_VEL);
  }
}
void doHold(char* cmd){ (void)cmd;
  feed();
  if (tempBlocked()) return;
  motor.controller = MotionControlType::torque;
  hold_angle = motor.shaft_angle;
  hold_vel_f = 0.0f;
  hold_integ = 0.0f;                     // [v2.6-Q] fresh integral each hold
  hold_tick  = ltick;                    // [v2.5-O] restart the soft engage
  setState(L_HOLD);
  Serial.print(F("ACK,H,")); Serial.println(hold_angle, 4);
}
void doCurr(char* cmd){
  feed();
  if (tempBlocked()) return;
  iq_target = clampf(atof(cmd), -P_iq_lim, P_iq_lim);
  if (state != L_CURR){
    motor.controller = MotionControlType::torque;
    iq_now = 0.0f;                 // first engagement always ramps from zero
    setState(L_CURR);
  }
  Serial.print(F("ACK,C,")); Serial.println(iq_target, 3);
}

// [v2] current-sense self-test: 1 s at 1 A, reports commanded vs measured.
// Run it with the shaft BLOCKED (arm resting on the load cell is ideal).
void doSelfTest(char* cmd){ (void)cmd;
  feed();
  if (tempBlocked()) return;
  if (!foc_ready){ Serial.println(F("EV,SELFTEST,ABORT,initFOC failed")); return; }
  motor.controller = MotionControlType::torque;
  setState(L_CURR);
  iq_target = 0; iq_now = 0;
  selftest_tick = 0; selftest_acc_cmd = 0; selftest_acc_meas = 0; selftest_n = 0;
  selftest = 1;
  Serial.println(F("ACK,Z,selftest 1s @ 1.0A - block the shaft"));
}

// [v2.3-M] RE-ALIGN. initFOC() finds zero_electric_angle by pushing the rotor
// to a known electrical angle and reading the sensor there. If the shaft is
// held — arm resting on the load cell, capstan loaded, gravity on the lever —
// the rotor CANNOT reach that position, and the angle it records is wrong by
// however far it was prevented from turning. Nothing complains: the sensor
// still reads, direction detection still passes, initFOC still returns 1.
//
// The damage is invisible to every check we have. Drive and measurement share
// the same wrong angle, so the loop still regulates measured Iq to setpoint
// and id still sits near zero — but the current vector lands off the true
// q axis, and torque falls by cos(angle error). Response stays perfectly
// linear; only the torque PER AMP is wrong, and it changes every time the
// rotor rests somewhere new.
//
// So: free the shaft, send 'A', and read the angle back. Once you have a
// trustworthy pair, hard-code them with 'Pz' / 'Pb' (the project logbook
// section 3.2 already recommends exactly this for the rehab firmware).
void doAlign(char* cmd){ (void)cmd;
  feed();
  if (state != L_IDLE){
    Serial.println(F("EV,ALIGN,ABORT,send O0 first")); return;
  }
  Serial.println(F("ACK,A,re-aligning - the shaft must be FREE to turn"));
  Serial.flush();
  if (ctrl_timer) ctrl_timer->pause();      // no loopFOC while initFOC drives
  // [v2.4-N] THE reason 'A' reported success without the motor moving:
  // alignSensor() runs its direction sweep only `if (sensor_direction ==
  // Direction::UNKNOWN)` and its offset capture only `if
  // (!_isset(zero_electric_angle))`. After the boot-time initFOC both are set,
  // so every later call logs "Skip dir calib." / "Skip offset calib.", touches
  // nothing, and returns 1. Clearing them is what forces a REAL re-alignment.
  motor.zero_electric_angle = NOT_SET;
  motor.sensor_direction    = Direction::UNKNOWN;
  motor.enable();
  int ok = motor.initFOC();
  foc_ready = (ok == 1);
  motor.PID_current_q.reset();
  motor.PID_current_d.reset();
  motor.disable();
  armed = false;
  if (ctrl_timer) ctrl_timer->resume();
  Serial.print(F("EV,ALIGN,"));  Serial.print(ok);
  Serial.print(F(",zea="));      Serial.print(motor.zero_electric_angle, 4);
  Serial.print(F(",dir="));      Serial.print((int)motor.sensor_direction);
  Serial.print(F(",pp_ok="));    Serial.println(motor.pp_check_result);
  if (!motor.pp_check_result)
    Serial.println(F("EV,MSG,pole-pair check FAILED - torque per amp will be wrong"));
}

// [v2.7-R] one-shot temperature dump — the raw node voltage as well as the
// converted number, because when a thermistor reading looks wrong the very
// first question is always "what is the ADC actually seeing".
void doTemp(char* cmd){ (void)cmd;
  feed();
  float v = _readRegularADCVoltage(THERM_PIN);
  float r = (v > 0.001f) ? P_th_rfix * (THERM_VREF / v - 1.0f) : -1.0f;
  Serial.print(F("EV,TEMPDUMP,v=")); Serial.print(v, 4);
  Serial.print(F(",r_ntc="));        Serial.print(r, 1);
  Serial.print(F(",tempC="));        Serial.print(temp_c, 2);
  Serial.print(F(",ok="));           Serial.print((int)temp_ok);
  Serial.print(F(",tripped="));      Serial.print((int)temp_tripped);
  Serial.print(F(",trip_at="));      Serial.print(P_temp_trip, 1);
  Serial.print(F(",beta="));         Serial.print(P_th_beta, 0);
  Serial.print(F(",r25="));          Serial.print(P_th_r25, 0);
  Serial.print(F(",rfix="));         Serial.println(P_th_rfix, 0);
}

// [v2.7.1-R] 'X<degC>' — solve beta from one reference point.
// You tell the firmware the true temperature of the bead right now (from a
// thermometer, or a stirred water bath), it reads the resistance, and it
// solves the only unknown in the beta equation:
//
//     beta = ln(R_ntc / R25) / (1/T_ref − 1/298.15)          [T in kelvin]
//
// TWO HONEST LIMITS, both enforced below:
//   1. This assumes R25 is exactly right, because one measurement cannot
//      separate R25 from beta. Set 'Ph' to the part's nominal first.
//   2. The denominator goes to zero at 25 C. Calibrating near room
//      temperature divides a small, noisy numerator by a small denominator
//      and produces a confident-looking beta that is nonsense — so a
//      reference within 10 C of 25 C is refused rather than answered.
// Hot water (60-80 C) with the bead and a thermometer in the same stirred
// cup is the easy way to do this well.
void doCalBeta(char* cmd){
  feed();
  float tref = atof(cmd);
  if (tref < -20.0f || tref > 150.0f){
    Serial.println(F("EV,MSG,X<degC>: give the bead's TRUE temperature, -20..150"));
    return;
  }
  if (fabsf(tref - 25.0f) < 10.0f){
    Serial.println(F("EV,MSG,X: too close to 25C to solve beta - use a bath 10C+ away (60-80C is ideal)"));
    return;
  }
  float v = _readRegularADCVoltage(THERM_PIN);
  if (!(v > 0.05f && v < (THERM_VREF - 0.05f))){
    Serial.print(F("EV,TEMPFAIL,")); Serial.println(v, 3);
    Serial.println(F("EV,MSG,X: cannot calibrate through a wiring fault"));
    return;
  }
  float r = P_th_rfix * (THERM_VREF / v - 1.0f);
  float dinv = 1.0f / (tref + 273.15f) - 1.0f / 298.15f;
  float beta = logf(r / P_th_r25) / dinv;
  if (!(isfinite(beta)) || beta < 500.0f || beta > 8000.0f){
    Serial.print(F("EV,MSG,X: solved beta=")); Serial.print(beta, 0);
    Serial.println(F(" is not credible - check Ph (R25) and the divider"));
    return;
  }
  P_th_beta = beta;
  temp_seeded = false;                 // re-seed the filter on the new scale
  Serial.print(F("EV,CALBETA,")); Serial.print(beta, 0);
  Serial.print(F(",r_ntc="));     Serial.print(r, 0);
  Serial.print(F(",tref="));      Serial.println(tref, 1);
  Serial.println(F("EV,MSG,runtime only - put this in P_th_beta in main.cpp to keep it"));
}

volatile uint32_t telem_period_ms = 20;
void doTelem(char* cmd){ feed(); telem_period_ms = (uint32_t)atoi(cmd);
  Serial.print(F("ACK,D,")); Serial.println((int)telem_period_ms); }

void doStat(char* cmd){ (void)cmd;
  feed();
  Serial.print(F("L fw="));      Serial.print(F(FW_VERSION));
  Serial.print(F(" state="));    Serial.print((int)state);
  Serial.print(F(" foc_init=")); Serial.print(foc_ready ? F("OK") : F("FAILED"));
  Serial.print(F(" mstatus="));  Serial.print((int)motor.motor_status);
  Serial.print(F(" enabled="));  Serial.print(motor.enabled);
  Serial.print(F(" vbus="));     Serial.print(vbus, 2);
  Serial.print(F(" vlim_drv=")); Serial.print(driver.voltage_limit, 2);
  Serial.print(F(" vlim_mot=")); Serial.print(motor.voltage_limit, 2);
  Serial.print(F(" ang="));      Serial.print(s_ang, 3);
  Serial.print(F(" vel="));      Serial.print(s_vel, 2);
  Serial.print(F(" iq_meas="));  Serial.print(s_iqm, 3);
  Serial.print(F(" iq_raw="));   Serial.print(motor.current.q, 3);  // ungated
  Serial.print(F(" id_meas="));  Serial.print(s_idm, 3);
  Serial.print(F(" iq_cmd="));   Serial.print(s_iqc, 3);
  Serial.print(F(" vq="));       Serial.print(s_vq, 3);
  Serial.print(F(" hold_Ki="));  Serial.print(P_Ki_hold, 1);
  Serial.print(F(" hold_I="));   Serial.print(hold_integ, 3);
  Serial.print(F(" iq_lim="));   Serial.print(P_iq_lim, 1);
  Serial.print(F(" pp="));       Serial.print(motor.pole_pairs);
  Serial.print(F(" pp_ok="));    Serial.print(motor.pp_check_result);
  Serial.print(F(" zea="));      Serial.print(motor.zero_electric_angle, 4);
  Serial.print(F(" sdir="));     Serial.print((int)motor.sensor_direction);
  Serial.print(F(" iq_sign="));  Serial.print(P_iq_sign, 0);
  Serial.print(F(" dir="));      Serial.print(P_dir, 0);
  Serial.print(F(" vmax="));     Serial.print(P_vmax, 1);
  Serial.print(F(" armed="));    Serial.print(armed);
  Serial.print(F(" wd_ms="));    Serial.print((int)P_wd_ms);
  Serial.print(F(" R="));        Serial.print(motor.phase_resistance, 4);
  Serial.print(F(" L="));        Serial.print(motor.phase_inductance, 6);
  Serial.print(F(" Pq="));       Serial.print(motor.PID_current_q.P, 4);
  Serial.print(F(" Iq_pid="));   Serial.print(motor.PID_current_q.I, 2);
  Serial.print(F(" sense="));    Serial.print(sense_ok ? F("OK") : F("DEAD"));
  Serial.print(F(" tempC="));    Serial.print(temp_ok ? temp_c : 0.0f, 1);
  Serial.print(F(" temp="));     Serial.print(temp_ok ? F("OK") : F("FAULT"));
  Serial.print(F(" trip_at="));  Serial.print(P_temp_trip, 1);
  Serial.print(F(" tripped=")); Serial.println((int)temp_tripped);
}

void doParam(char* cmd){
  feed();
  char k = cmd[0]; float v = atof(&cmd[1]);
  switch(k){
    case 'i': P_iq_lim  = clampf(v, 0.2f, 10.0f); motor.current_limit = P_iq_lim; break;
    case 'p': P_Kp_hold = clampf(v, 0.0f, 100.0f); break;
    case 'd': P_Kd_hold = clampf(v, 0.0f, 10.0f);  break;
    case 'f': P_hold_tf = clampf(v, 0.0f, 0.2f);   break;   // [v2.5-O]
    case 'k': P_Ki_hold = clampf(v, 0.0f, 200.0f); hold_integ = 0.0f; break;  // [v2.6-Q]
    case 'q': P_iq_sign = (v < 0) ? -1.0f : 1.0f; iqcal_done = true; break;
    case 's': P_dir     = (v < 0) ? -1.0f : 1.0f;  break;   // [v2-C]
    case 'r': P_iq_ramp = clampf(v, 0.1f, 20.0f);  break;
    case 'c': P_Kd_curr = clampf(v, 0.0f, 0.5f);   break;
    case 'v': P_vmax    = clampf(v, 0.0f, 300.0f); break;   // 0 = OFF [v2.2-K]
    case 't': P_wd_ms   = (uint32_t)clampf(v, 0.0f, 60000.0f); break;  // [v2-A]
    case 'a': P_iqcal_en = (v > 0.5f) ? 1 : 0; iqcal_done = false;
              iqcal_acc = 0; iqcal_n = 0; break;
    case 'w': P_R = clampf(v, 0.01f, 100.0f); motor.phase_resistance = P_R; break;
    case 'l': P_L = clampf(v, 1e-6f, 0.1f);   motor.phase_inductance = P_L;
              motor.axis_inductance = {P_L, P_L}; break;
    case 'n': P_bw = clampf(v, 5.0f, 2000.0f);
              Serial.print(F("tune=")); Serial.println(motor.tuneCurrentController(P_bw));
              break;
    case 'u': P_vbus_override = clampf(v, 0.0f, 60.0f);
              if (P_vbus_override > 5.0f){
                vbus = P_vbus_override; vbus_ok = true;
                driver.voltage_power_supply = vbus;
                driver.voltage_limit = vbus;
                if (motor.voltage_limit > vbus) motor.voltage_limit = vbus;
                motor.PID_current_q.limit = motor.voltage_limit;
                motor.PID_current_d.limit = motor.voltage_limit;
              }
              break;
    // ---- [v2.7-R] thermistor ----
    case 'j': P_temp_trip = clampf(v, 0.0f, 200.0f);
              if (P_temp_trip <= 0.0f) temp_tripped = false; break;
    case 'e': P_th_beta = clampf(v, 500.0f, 8000.0f);  break;
    case 'h': P_th_r25  = clampf(v, 100.0f, 1000000.0f); break;
    case 'o': P_th_rfix = clampf(v, 100.0f, 1000000.0f); break;
    case 'y': P_th_off  = clampf(v, -50.0f, 50.0f);    break;
    case 'z': motor.zero_electric_angle = v; break;              // [v2.3-M]
    case 'b': motor.sensor_direction =
                (v < 0) ? Direction::CCW : Direction::CW; break;   // [v2.3-M]
    case 'm': {
      int tm = (int)v;
      motor.torque_controller =
          (tm==0) ? TorqueControlType::voltage
        : (tm==1) ? TorqueControlType::dc_current
                  : TorqueControlType::foc_current;
      break; }
    default: Serial.println(F("P? i p d f k q s r c v t a w l n u m z b j e h o y  (also T, X<degC>)")); return;
  }
  Serial.print(F("P ")); Serial.print(k); Serial.print('='); Serial.println(v, 4);
}

// ======================= setup ====================================
void setup(){
  _delay(3000);
  Serial.begin(921600);
  SimpleFOCDebug::enable(&Serial);

  pinMode(VSENS, INPUT_ANALOG);
  // [v2.7-R] the thermistor node, configured here alongside VSENS and BEFORE
  // driver.init(), so the pin is a plain analogue input before any timer or
  // current-sense configuration touches the ADC.
  pinMode(THERM_PIN, INPUT_ANALOG);
  vbus = _readRegularADCVoltage(VSENS)*VSCALE;
  // [v2-F] a bad VSENS read silently caps every phase voltage at ~0 V:
  // no torque, no current, and NO error anywhere. Guard it loudly.
  vbus_ok = (vbus > 6.0f && vbus < 60.0f);
  if (!vbus_ok){
    Serial.print(F("EV,VBUS,")); Serial.println(vbus, 2);
    Serial.println(F("EV,MSG,VSENS out of range - assuming 24V. Override with Pu<volts>."));
    vbus = 24.0f;
  }
  SIMPLEFOC_DEBUG(" V sens: ", vbus);

  driver.voltage_power_supply = vbus;
  driver.voltage_limit = vbus;
  driver.dead_zone = 0.001f;
  driver.init();
  delay(10);

  // DRV8301 gain config (same as ExArMo)
  pinMode(M0_nCS, OUTPUT);
  digitalWrite(M0_nCS, HIGH);
  SPI_3.begin();
  SPI_3.beginTransaction(SPISettings(1000000, MSBFIRST, SPI_MODE1));
  digitalWrite(M0_nCS, LOW);
  SPI_3.transfer(0x18);
  SPI_3.transfer(0x03);
  digitalWrite(M0_nCS, HIGH);
  SPI_3.endTransaction();

  motor.linkDriver(&driver);
  sensor.init(&SPI_3);
  motor.linkSensor(&sensor);

  motor.torque_controller = TorqueControlType::foc_current;
  motor.controller = MotionControlType::torque;
  motor.voltage_limit = (vbus < 24.0f) ? vbus : 24.0f;
  motor.voltage_sensor_align = 1.5;
  motor.current_limit = P_iq_lim;
  motor.velocity_limit = 350;     // rad/s — KV tests need headroom

  // [v2-E] electrical parameters BEFORE initFOC/tuning, so
  // tuneCurrentController() never falls back to characteriseMotor().
  motor.phase_resistance = P_R;
  motor.phase_inductance = P_L;
  motor.axis_inductance  = {P_L, P_L};
  motor.KV_rating = 114.1f;

  // [v2-I] monitor configured exactly like the rehab firmware, so the proven
  // simplefoc_loadcell_gui.py can be pointed at this board as a cross-check
  // (it sends MMS0001001 + MMD10). monitor() prints current in mA.
  motor.useMonitoring(Serial);
  motor.monitor_variables = _MON_CURR_Q | _MON_ANGLE;
  motor.monitor_separator = ',';
  motor.monitor_start_char = 'M';
  motor.monitor_end_char   = 'M';
  motor.monitor_downsample = 0;          // off until MMD<n> turns it on

  command.add('M', doMotor,    "motor M0");
  command.add('V', doVel,      "velocity [rad/s]");
  command.add('H', doHold,     "hold current angle");
  command.add('C', doCurr,     "current Iq [A]");
  command.add('O', doMode,     "O0 stop");
  command.add('S', doStopS,    "stop");
  command.add('D', doTelem,    "telemetry period ms");
  command.add('K', doKeep,     "keepalive");
  command.add('L', doStat,     "status");
  command.add('Z', doSelfTest, "current sense self-test");
  command.add('A', doAlign,    "re-align sensor (shaft must be free)");
  command.add('T', doTemp,     "thermistor dump");            // [v2.7-R]
  command.add('X', doCalBeta,  "solve beta from a reference temp"); // [v2.7.1-R]
  command.add('P', doParam,    "params");

  commandc.init();
  commandc.addMotor(&motor);

  motor.init();
  current_sense.linkDriver(&driver);
  bool cs_ok = current_sense.init();
  current_sense.skip_align = true;
  motor.linkCurrentSense(&current_sense);
  if (!cs_ok) Serial.println(F("EV,MSG,current_sense.init() FAILED - Iq will read 0"));

  foc_ready = (motor.initFOC() == 1);

  motor.tuneCurrentController(P_bw);     // deterministic now (R and L are set)
  delay(200);

  motor.motion_downsample = 0;

  HardwareTimer* timer = new HardwareTimer(TIM8);
  ctrl_timer = timer;
  timer->setOverflow(20000, HERTZ_FORMAT);
  static int ctr = 0;
  timer->attachInterrupt([](){
    motor.loopFOC();
    if(++ctr >= CTRL_DIV){ ctr = 0; controlUpdate(); }
  });
  timer->resume();

  last_rx_ms = millis();
  // [v2.7-R] first thermistor read AFTER the control timer is live, so if the
  // sensor and the FOC loop do fight over the ADC it shows up here at boot
  // rather than halfway through a 40-minute thermal run.
  temp_last_ms = millis();
  thermUpdate();

  Serial.print(F("EV,BOOT,")); Serial.println(F(FW_VERSION));
  Serial.print(F("EV,VBUS,")); Serial.println(vbus, 2);
  if (temp_ok){ Serial.print(F("EV,TEMPOK,")); Serial.println(temp_c, 1); }
  else         Serial.println(F("EV,MSG,no thermistor on GPIO3/PA2 - temp field is 0 and flags bit5 is clear"));
  ev_tempok = false; ev_tempfail = false;   // announced right here, once
  Serial.println(F("READY. V/H/C to run, O0 to stop, Z to self-test, L for status."));
}

// ======================= loop =====================================
void loop(){
  // Kept as a bonus stamp only — the watchdog is actually fed by feed()
  // inside every Commander callback. See [v2-A].
  if (Serial.available()) feed();

  if (ev_state)   { ev_state = false;
                    Serial.print(F("EV,STATE,")); Serial.println((int)state); }
  if (ev_watchdog){ ev_watchdog = false;
                    Serial.println(F("EV,WATCHDOG,host silent - stopped")); }
  if (ev_nonfinite){ ev_nonfinite = false;
                    Serial.println(F("EV,MSG,non-finite value in the control loop - published 0")); }
  if (ev_runaway) { ev_runaway = false;
                    Serial.print(F("EV,RUNAWAY,")); Serial.println(ev_a, 2);
                    Serial.println(F("EV,MSG,free shaft ran away - stopped. Load the shaft, or lower Pv.")); }
  if (ev_iqsign)  { ev_iqsign = false;
                    Serial.print(F("EV,IQSIGN,")); Serial.println(P_iq_sign, 0); }
  if (ev_sensefail){ ev_sensefail = false;
                    Serial.print(F("EV,SENSEFAIL,")); Serial.print(ev_a, 3);
                    Serial.print(','); Serial.println(ev_b, 3);
                    Serial.println(F("EV,MSG,commanding current but measuring none - check shunt wiring / Pm / Pq")); }
  // ---- [v2.7-R] thermistor at 5 Hz ----
  // A motor's thermal time constant is minutes; 5 Hz is already far more than
  // the physics needs, and it keeps the shared-ADC poll out of the way.
  if (millis() - temp_last_ms >= 200){
    temp_last_ms = millis();
    thermUpdate();
  }
  if (ev_temptrip){ ev_temptrip = false;
                    Serial.print(F("EV,TEMP,")); Serial.println(ev_t, 1);
                    Serial.println(F("EV,MSG,OVER-TEMPERATURE - stopped. Let it cool, or raise Pj.")); }
  if (ev_tempfail){ ev_tempfail = false;
                    Serial.print(F("EV,TEMPFAIL,")); Serial.println(ev_t, 3);
                    Serial.println(F("EV,MSG,thermistor open/shorted - check the bead on GPIO3/PA2 (T dumps the raw volts)")); }
  if (ev_tempok)  { ev_tempok = false;
                    Serial.print(F("EV,TEMPOK,")); Serial.println(ev_t, 1); }

  if (selftest == 2){ selftest = 0; selftest_tick = 0;
                    Serial.print(F("EV,SELFTEST,")); Serial.print(ev_a, 3);
                    Serial.print(','); Serial.println(ev_b, 3);
                    doStop_(); }

  // a failed FOC init is otherwise invisible after boot — repeat it
  static uint32_t last_health = 0;
  if (!foc_ready && millis() - last_health > 3000){
    last_health = millis();
    Serial.println(F("EV,FOCFAIL,initFOC failed - check sensor magnet / pole pairs / power. Motor cannot move."));
  }

  static uint32_t last = 0;
  uint32_t now = millis();
  if (telem_period_ms > 0 && now - last >= telem_period_ms){
    last = now;
    uint8_t flags = (foc_ready      ? 0x01 : 0)
                  | (motor.enabled  ? 0x02 : 0)
                  | (armed          ? 0x04 : 0)
                  | (sense_ok       ? 0x08 : 0)
                  | (vbus_ok        ? 0x10 : 0)
                  | (temp_ok        ? 0x20 : 0);   // [v2.7-R]
    // D,t_ms,state,angle,vel,iq_meas,iq_cmd,id_meas,vq,flags,temp_C
    Serial.print("D,"); Serial.print(now);   Serial.print(',');
    Serial.print((int)state);                Serial.print(',');
    Serial.print(s_ang, 4);                  Serial.print(',');
    Serial.print(s_vel, 3);                  Serial.print(',');
    Serial.print(s_iqm, 3);                  Serial.print(',');
    Serial.print(s_iqc, 3);                  Serial.print(',');
    Serial.print(s_idm, 3);                  Serial.print(',');
    Serial.print(s_vq, 3);                   Serial.print(',');
    Serial.print((int)flags);                Serial.print(',');
    // 0 when the sensor is not trustworthy — see the header note: read bit5,
    // not this number.
    Serial.println(temp_ok ? safef(temp_c) : 0.0f, 1);
  }
  motor.monitor();
  command.run();
  commandc.run();
}