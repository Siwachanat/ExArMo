#!/usr/bin/env python3
"""
ExArMo Lab — Motor Tester GUI  (v2.0, light theme, paper-ready)
===============================================================
Companion to the DEDICATED lab firmware `src/main.cpp` v2.0 (NOT the ExArMo
rehab firmware). All quantities are MOTOR-SHAFT units from the device link.

WHAT CHANGED FROM v1 (and why nothing showed up before)
-------------------------------------------------------
[g2-A] `dev["last"]` was the ONLY channel for firmware messages, and
       `dev_send()` overwrote it with "> K" every single keepalive. So
       EV,FOCFAIL / EV,WATCHDOG / ACK lines were clobbered within a second of
       arriving and the footer banner could essentially never fire. TX and RX
       are now separate, faults are STICKY, and there is a real scrolling
       console on the Diagnostics tab.
[g2-B] The step engine assumed the arm reached the load cell after a fixed
       ~2 s "engage" wait. It never checked. If the arm was short of the cell
       (or pushing the wrong way) every step recorded 0 g with no complaint.
       Engagement now WAITS FOR CONTACT — a real rise in grams — and aborts
       with a clear message if contact never happens.
[g2-C] No way to verify push DIRECTION before a sweep. A direction toggle
       ('Ps±1') and a manual jog live on the Diagnostics tab now.
[g2-D] Telemetry gained id, voltage.q and a health/flags word, so the GUI can
       distinguish "no current commanded" from "current commanded but not
       measured" from "FOC never initialised".
[g2-E] Connect now resets the board (O0), sets the telemetry rate and asks for
       a status dump, instead of trusting whatever state the board was left in.
[g2-F] Keepalive raised to 2 Hz against the firmware's 3 s watchdog.

Tabs:
 0  Diagnostics       console, live flags, jog, direction, self-test
 1  KV · Back-EMF     spin at speed steps, type multimeter V, live KV fit
 2  KT · Add weight   freewheel → rotate arm horizontal → HOLD; add weights,
                      record averaged Iq per step; fit τ vs Iq → Kt
 3  KT · Loadcell     Iq steps; per step wait `settle` (discard) then average
                      the loadcell robustly; fit Kt              [2nd serial]
 4  Heat over force   constant Iq; log loadcell+temperature every 1 s with a
                      high-temperature auto-stop                 [2nd serial]
 5  Capstan torque    same engine as 3 through the capstan; output Kt and
                      optional efficiency vs the motor Kt from tab 3

Device telemetry (10 fields):
    D,t_ms,state,angle,vel,iq_meas,iq_cmd,id_meas,vq,flags
Loadcell/temp Arduino protocol (2nd serial, 115200): one line per sample,
"grams" or "grams,tempC"  e.g.  "512.3,41.7"

Run:  pip install pyserial   →   python ExarmoLabGui.py
"""

import tkinter as tk
import tkinter.ttk as ttk
import threading, time, math, csv, os, re, collections
from datetime import datetime
import serial, serial.tools.list_ports

BAUD_DEV = 921600
BAUD_LC  = 115200
TELEM_MS = 20
KEEPALIVE_S = 0.5          # [g2-F] 2 Hz against the firmware's 3 s watchdog
G_ACC    = 9.80665

# ── light theme (paper-friendly) ───────────────────────────────
BG      = "#f2f4f8"
SURFACE = "#ffffff"
FIELD   = "#eef1f6"
BORDER  = "#d5dbe6"
TEXT    = "#1c2433"
MUTED   = "#5c6a80"
FAINT   = "#8b96a8"
BLUE    = "#2563eb"
GREEN   = "#118a52"
RED     = "#d3455b"
AMBER   = "#b45309"
PURPLE  = "#7c3aed"

F_TITLE = ("Segoe UI", 24, "bold")
F_H     = ("Segoe UI", 13, "bold")
F_LBL   = ("Segoe UI", 13)
F_SM    = ("Segoe UI", 11)
F_BTN   = ("Segoe UI", 13, "bold")
F_MONO  = ("Consolas", 16)
F_BIG   = ("Consolas", 40, "bold")

STATE_NAMES = {0: "IDLE (free)", 1: "VELOCITY", 2: "HOLDING", 3: "CURRENT"}

FLAG_BITS = [(0x01, "FOC init"), (0x02, "motor enabled"),
             (0x04, "FOC armed (driving)"), (0x08, "current sense"), (0x10, "Vbus")]

running = True

# ── device link (lab firmware) ─────────────────────────────────
dev = dict(ser=None, lock=threading.Lock())
# [g2-A] three SEPARATE channels. v1 had one string that the keepalive echo
# overwrote twice a second, which is why firmware faults were never visible.
link = dict(tx="", rx="", fault="", fw="")
console = collections.deque(maxlen=500)
console_seq = [0]          # monotonic — len() saturates once the deque is full
console_lock = threading.Lock()

T = dict(state=0, ang=0.0, vel=0.0, iq=0.0, iqc=0.0, idq=0.0, vq=0.0,
         flags=-1, t_rx=0.0, nfields=0)
iq_hist  = collections.deque(maxlen=800)     # (t, iq_meas)
iqc_hist = collections.deque(maxlen=800)     # (t, iq_cmd from firmware)
rpm_hist = collections.deque(maxlen=800)     # (t, rpm)


def clog(text, kind="rx"):
    with console_lock:
        console.append((time.strftime("%H:%M:%S"), kind, text))
        console_seq[0] += 1


def dev_send(cmd):
    with dev["lock"]:
        s = dev["ser"]
        if s is None or not s.is_open:
            link["fault"] = "device not connected"
            return False
        try:
            s.write((cmd + "\n").encode())
            link["tx"] = cmd
            if cmd != "K":                       # don't spam the console
                clog(cmd, "tx")
            return True
        except Exception as e:
            link["fault"] = f"tx error: {e}"
            clog(f"tx error: {e}", "err")
            return False


def dev_reader():
    last_keep = 0.0
    while running:
        s = dev["ser"]
        if s is None or not s.is_open:
            time.sleep(0.2)
            continue
        if time.time() - last_keep > KEEPALIVE_S:        # watchdog food
            dev_send("K")
            last_keep = time.time()
        try:
            raw = s.readline()
        except Exception as e:
            link["fault"] = f"rx error: {e}"
            time.sleep(0.2)
            continue
        if not raw:
            continue
        line = raw.decode(errors="replace").strip()
        if not line:
            continue

        if line.startswith("D,"):
            p = line.split(",")
            T["nfields"] = len(p)
            if len(p) >= 13:
                # 13 fields = the ExArMo REHAB firmware is flashed, not the lab
                # firmware — every lab command would misbehave
                link["fault"] = "WRONG FIRMWARE: flash the labtest main.cpp"
                continue
            if len(p) >= 6:
                try:
                    T["state"] = int(p[2]); T["ang"] = float(p[3])
                    T["vel"] = float(p[4]); T["iq"] = float(p[5])
                    T["iqc"] = float(p[6]) if len(p) >= 7 else 0.0
                    # v2 extras (absent on the old 7-field firmware)
                    T["idq"]   = float(p[7]) if len(p) >= 8 else 0.0
                    T["vq"]    = float(p[8]) if len(p) >= 9 else 0.0
                    T["flags"] = int(float(p[9])) if len(p) >= 10 else -1
                    now = time.time()
                    T["t_rx"] = now
                    iq_hist.append((now, T["iq"]))
                    iqc_hist.append((now, T["iqc"]))
                    rpm_hist.append((now, T["vel"] * 60.0 / (2 * math.pi)))
                except ValueError:
                    pass
            continue

        # everything that is not telemetry is a message worth keeping
        link["rx"] = line
        clog(line, "err" if ("FAIL" in line or "WATCHDOG" in line) else "rx")
        if line.startswith("EV,BOOT,"):
            link["fw"] = line.split(",", 2)[-1]
            link["fault"] = ""
        elif "FOCFAIL" in line:
            link["fault"] = "initFOC FAILED — motor cannot move (check magnet / pole pairs / power)"
        elif "SENSEFAIL" in line:
            link["fault"] = "CURRENT SENSE DEAD — commanding current, measuring none"
        elif "WATCHDOG" in line:
            link["fault"] = "WATCHDOG tripped — host went silent, motor released"
        elif "RUNAWAY" in line:
            link["fault"] = ("RUNAWAY trip — the shaft was free and accelerated away. "
                             "Load it against the cell before jogging, or lower Pv.")
        elif line.startswith("EV,SELFTEST,"):
            link["fault"] = ""


def dev_connect(port):
    dev_disconnect()
    try:
        s = serial.Serial(port, BAUD_DEV, timeout=0.2)
        time.sleep(0.4)
        s.reset_input_buffer()
        with dev["lock"]:
            dev["ser"] = s
        link["fault"] = ""
        clog(f"--- connected {port} @ {BAUD_DEV} ---", "sys")
        # [g2-E] never trust whatever state the board was left in
        dev_send("O0")
        dev_send(f"D{TELEM_MS}")
        dev_send("L")
        dev_status.config(text=f"● {port}", fg=GREEN)
    except Exception as e:
        dev_status.config(text=f"● {e}", fg=RED)
        clog(f"connect failed: {e}", "err")


def dev_disconnect():
    with dev["lock"]:
        if dev["ser"] is not None:
            try:
                dev["ser"].write(b"O0\n"); dev["ser"].close()
            except Exception:
                pass
            dev["ser"] = None


def dev_alive():
    return T["t_rx"] > 0 and (time.time() - T["t_rx"]) < 1.0


# ── loadcell / temperature link (Arduino) ──────────────────────
lc = dict(ser=None, lock=threading.Lock(), last="")
lc_buf = collections.deque(maxlen=8000)      # (t, grams, tempC or None)

_num = re.compile(r"[-+]?\d+(?:\.\d+)?")


def lc_reader():
    while running:
        s = lc["ser"]
        if s is None or not s.is_open:
            time.sleep(0.2)
            continue
        try:
            raw = s.readline()
        except Exception:
            time.sleep(0.2)
            continue
        if not raw:
            continue
        line = raw.decode(errors="replace").strip()
        nums = _num.findall(line)
        if not nums:
            continue
        try:
            grams = float(nums[0])
            temp = float(nums[1]) if len(nums) > 1 else None
            lc_buf.append((time.time(), grams, temp))
            lc["last"] = line
        except ValueError:
            pass


def lc_connect(port):
    lc_disconnect()
    try:
        s = serial.Serial(port, BAUD_LC, timeout=0.2)
        time.sleep(0.3)
        with lc["lock"]:
            lc["ser"] = s
        lc_status.config(text=f"● {port}", fg=GREEN)
    except Exception as e:
        lc_status.config(text=f"● {e}", fg=RED)


def lc_disconnect():
    with lc["lock"]:
        if lc["ser"] is not None:
            try:
                lc["ser"].close()
            except Exception:
                pass
            lc["ser"] = None


def lc_window(t0, t1):
    """samples with t0 <= t <= t1"""
    return [s for s in lc_buf if t0 <= s[0] <= t1]


def lc_latest(seconds=0.4):
    now = time.time()
    vals = [g for (t, g, _) in lc_buf if now - t <= seconds]
    return robust_mean(vals)[0] if vals else None


def robust_mean(vals, trim=0.2):
    """trimmed mean + std: sort, drop `trim` fraction each side, average."""
    if not vals:
        return None, None
    v = sorted(vals)
    k = int(len(v) * trim)
    core = v[k:len(v) - k] if len(v) - 2 * k >= 1 else v
    m = sum(core) / len(core)
    sd = (sum((x - m) ** 2 for x in core) / len(core)) ** 0.5
    return m, sd


def sense_alive():
    """measured-current path considered alive if it shows real signal while
    the firmware is commanding current"""
    now = time.time()
    meas = [abs(i) for (t, i) in iq_hist if now - t <= 2.0]
    cmd = [abs(i) for (t, i) in iqc_hist if now - t <= 2.0]
    if not meas or not cmd:
        return True                      # no data yet: don't cry wolf
    if max(cmd) < 0.05:
        return True                      # nothing commanded: can't judge
    return max(meas) > 0.25 * max(cmd)


def iqc_avg(seconds=1.0):
    now = time.time()
    return robust_mean([i for (t, i) in iqc_hist if now - t <= seconds])


def iq_avg(seconds=1.0):
    now = time.time()
    return robust_mean([i for (t, i) in iq_hist if now - t <= seconds])


# ── logging ────────────────────────────────────────────────────
def serial_no():
    return re.sub(r"[^A-Za-z0-9_\-]", "-", e_serial.get().strip())


def log_path(experiment):
    sn = serial_no()
    if not sn:
        return None
    os.makedirs("labdata", exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"labdata/{sn}_{experiment}_{ts}.csv"


def linfit(xs, ys):
    n = len(xs)
    mx = sum(xs) / n; my = sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    if sxx < 1e-12:
        return None
    a = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx
    b = my - a * mx
    ss_res = sum((y - (a * x + b)) ** 2 for x, y in zip(xs, ys))
    ss_tot = sum((y - my) ** 2 for y in ys)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 1e-12 else 1.0
    return a, b, r2


# ── UI helpers ─────────────────────────────────────────────────
root = tk.Tk()
root.title("ExArMo Lab — Motor Tester")
root.geometry("1660x980")
root.configure(bg=BG)


def card(parent):
    o = tk.Frame(parent, bg=BORDER, padx=1, pady=1)
    i = tk.Frame(o, bg=SURFACE, padx=22, pady=18)
    i.pack(fill="both", expand=True)
    return o, i


def section(parent, text):
    tk.Label(parent, text=text.upper(), bg=SURFACE, fg=FAINT,
             font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 8))


def btn(parent, text, bg, fg, cmd, width=None):
    b = tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg,
                  activebackground=bg, activeforeground=fg, relief="flat",
                  bd=0, font=F_BTN, padx=18, pady=10, cursor="hand2",
                  highlightthickness=0)
    if width:
        b.config(width=width)
    return b


def entry_row(parent, label, default, width=8):
    f = tk.Frame(parent, bg=SURFACE)
    f.pack(fill="x", pady=3)
    tk.Label(f, text=label, bg=SURFACE, fg=TEXT, font=F_LBL).pack(side="left")
    e = tk.Entry(f, bg=FIELD, fg=BLUE, insertbackground=TEXT, relief="flat",
                 font=("Consolas", 14, "bold"), width=width, justify="center",
                 highlightthickness=1, highlightbackground=BORDER,
                 highlightcolor=BLUE)
    e.insert(0, str(default))
    e.pack(side="right", ipady=3)
    return e


def mkstatus(parent):
    l = tk.Label(parent, text="●  Ready", bg=SURFACE, fg=MUTED, font=F_LBL,
                 wraplength=330, justify="left")
    l.pack(anchor="w", pady=(8, 0))

    def set_(t, c):
        l.config(text="●  " + t, fg=c)
    return set_


def big_value(parent, caption, color=BLUE):
    v = tk.Label(parent, text="—", bg=SURFACE, fg=color, font=F_BIG)
    v.pack()
    tk.Label(parent, text=caption, bg=SURFACE, fg=FAINT, font=F_SM).pack()
    return v


STYLE = ttk.Style(); STYLE.theme_use("clam")
STYLE.configure("Treeview", background=SURFACE, fieldbackground=SURFACE,
                foreground=TEXT, rowheight=28, font=("Consolas", 12),
                borderwidth=0)
STYLE.configure("Treeview.Heading", background=FIELD, foreground=MUTED,
                font=("Segoe UI", 10, "bold"), borderwidth=0)


def mktable(parent, cols, height=8):
    t = ttk.Treeview(parent, columns=[c[0] for c in cols], show="headings",
                     height=height)
    for cid, txt, w in cols:
        t.heading(cid, text=txt)
        t.column(cid, width=w, anchor="center")
    t.pack(pady=(8, 6))
    return t


def draw_ts(cv, series, color, ylabel, marks=(), y2=None, color2=PURPLE):
    """simple time-series plot; series/y2 = list[(t, v)] (last 60 s shown)"""
    cv.delete("all")
    w = int(cv.winfo_width() or 600); h = int(cv.winfo_height() or 240)
    cv.create_rectangle(1, 1, w - 1, h - 1, outline=BORDER, fill="#fbfcfe")
    now = time.time(); t0 = now - 60.0

    def plot(data, col):
        pts = [(t, v) for (t, v) in data if t >= t0 and v is not None]
        if len(pts) < 2:
            return None
        vs = [v for _, v in pts]
        lo, hi = min(vs), max(vs)
        pad = 0.1 * (hi - lo) + 1e-6
        lo -= pad; hi += pad
        poly = []
        for t, v in pts:
            x = (t - t0) / 60.0 * (w - 20) + 10
            y = h - 14 - (v - lo) / (hi - lo) * (h - 28)
            poly += [x, y]
        cv.create_line(*poly, fill=col, width=2)
        return lo, hi

    plot(series, color)
    if y2:
        plot(y2, color2)
    for tm in marks:
        if tm >= t0:
            x = (tm - t0) / 60.0 * (w - 20) + 10
            cv.create_line(x, 10, x, h - 10, fill=BORDER, dash=(3, 4))
    cv.create_text(12, 12, text=ylabel, fill=MUTED, font=F_SM, anchor="nw")


# ── header ─────────────────────────────────────────────────────
head = tk.Frame(root, bg=SURFACE)
head.pack(fill="x")
hb = tk.Frame(head, bg=SURFACE); hb.pack(side="left", padx=22, pady=12)
tk.Label(hb, text="Ex", bg=SURFACE, fg=AMBER, font=F_TITLE).pack(side="left")
tk.Label(hb, text="ArMo Lab", bg=SURFACE, fg=TEXT, font=F_TITLE).pack(side="left")

sn_f = tk.Frame(head, bg=SURFACE); sn_f.pack(side="left", padx=30)
tk.Label(sn_f, text="Motor serial no.", bg=SURFACE, fg=MUTED, font=F_LBL).pack(side="left", padx=(0, 8))
e_serial = tk.Entry(sn_f, bg=FIELD, fg=TEXT, insertbackground=TEXT, relief="flat",
                    font=("Consolas", 15, "bold"), width=14, justify="center",
                    highlightthickness=1, highlightbackground=BORDER, highlightcolor=BLUE)
e_serial.pack(side="left", ipady=4)


def port_picker(parent, label, connect_fn, baud):
    f = tk.Frame(parent, bg=SURFACE); f.pack(side="left", padx=14)
    tk.Label(f, text=label, bg=SURFACE, fg=MUTED, font=F_SM).pack(side="left", padx=(0, 6))
    var = tk.StringVar()
    ports = [p.device for p in serial.tools.list_ports.comports()] or ["—"]
    var.set(ports[0])
    om = tk.OptionMenu(f, var, *ports)
    om.config(bg=FIELD, fg=TEXT, relief="flat", bd=0, highlightthickness=0, font=F_SM)
    om.pack(side="left")

    def refresh():
        m = om["menu"]; m.delete(0, "end")
        for p in [q.device for q in serial.tools.list_ports.comports()] or ["—"]:
            m.add_command(label=p, command=lambda v=p: var.set(v))
    tk.Button(f, text="↻", command=refresh, bg=FIELD, fg=MUTED, relief="flat",
              bd=0, font=F_SM, padx=6, cursor="hand2", highlightthickness=0).pack(side="left", padx=3)
    tk.Button(f, text="Connect", command=lambda: connect_fn(var.get()), bg=FIELD,
              fg=BLUE, relief="flat", bd=0, font=("Segoe UI", 11, "bold"),
              padx=10, pady=3, cursor="hand2", highlightthickness=0).pack(side="left")
    st = tk.Label(f, text="● off", bg=SURFACE, fg=FAINT, font=F_SM)
    st.pack(side="left", padx=(6, 0))
    return st


conn_f = tk.Frame(head, bg=SURFACE); conn_f.pack(side="right", padx=18)
dev_status = port_picker(conn_f, "Driver", dev_connect, BAUD_DEV)
lc_status = port_picker(conn_f, "Loadcell/Temp", lc_connect, BAUD_LC)

# tab bar
tabs_bar = tk.Frame(root, bg=SURFACE)
tabs_bar.pack(fill="x")
tk.Frame(root, bg=BORDER, height=1).pack(fill="x")

# [g2-A] sticky fault banner — a firmware fault stays on screen until it is
# cleared by a good event, instead of being overwritten by the next keepalive.
banner = tk.Label(root, text="", bg="#fdecee", fg=RED, font=("Segoe UI", 12, "bold"),
                  anchor="w", padx=18, pady=6)

body = tk.Frame(root, bg=BG)
body.pack(fill="both", expand=True, padx=24, pady=18)

foot = tk.Frame(root, bg=SURFACE)
foot.pack(side="bottom", fill="x")
tk.Frame(root, bg=BORDER, height=1).pack(side="bottom", fill="x")
foot_state = tk.Label(foot, text="—", bg=SURFACE, fg=MUTED,
                      font=("Segoe UI", 12, "bold"))
foot_state.pack(side="left", padx=(22, 16), pady=6)
foot_line = tk.Label(foot, text="", bg=SURFACE, fg=FAINT, font=("Consolas", 12),
                     anchor="w")
foot_line.pack(side="left", fill="x", expand=True)


def foot_tick():
    live = dev_alive()
    foot_state.config(text=STATE_NAMES.get(T["state"], "?") + ("" if live else "  (no telemetry)"),
                      fg=GREEN if (live and T["state"]) else (MUTED if live else RED))
    foot_line.config(text=f"rx: {link['rx'][-90:]}    tx: {link['tx'][-20:]}", fg=FAINT)
    if link["fault"]:
        banner.config(text="⚠  " + link["fault"] + "     (Diagnostics tab has the full console)")
        banner.pack(fill="x", before=body)
    else:
        banner.pack_forget()
    root.after(200, foot_tick)


TABS = []
cur_tab = [0]


def add_tab(name, frame):
    idx = len(TABS)
    b = tk.Label(tabs_bar, text=name, bg=SURFACE, fg=MUTED,
                 font=("Segoe UI", 13, "bold"), padx=16, pady=9, cursor="hand2")
    b.pack(side="left", padx=(14 if idx == 0 else 2, 2))
    b.bind("<Button-1>", lambda e, k=idx: show_tab(k))
    TABS.append((b, frame))


def show_tab(k):
    cur_tab[0] = k
    for i, (b, f) in enumerate(TABS):
        if i == k:
            b.config(bg=FIELD, fg=BLUE)
            f.pack(fill="both", expand=True)
        else:
            b.config(bg=SURFACE, fg=MUTED)
            f.pack_forget()


def stop_all():
    dev_send("O0")


# ═════════════ TAB 0 · DIAGNOSTICS ═════════════════════════════
# This tab exists because v1 gave you no way to answer the only question that
# matters when nothing happens: WHICH link is broken — FOC init, the command
# path, the direction, or the current sense?
dg_fr = tk.Frame(body, bg=BG)

dg_l_o, dg_l = card(dg_fr); dg_l_o.pack(side="left", fill="y", padx=(0, 14))
section(dg_l, "Firmware health")
dg_flag_lbls = []
for _bit, _name in FLAG_BITS:
    r = tk.Frame(dg_l, bg=SURFACE); r.pack(fill="x", pady=2)
    dot = tk.Label(r, text="●", bg=SURFACE, fg=FAINT, font=("Segoe UI", 14))
    dot.pack(side="left", padx=(0, 8))
    tk.Label(r, text=_name, bg=SURFACE, fg=TEXT, font=F_LBL).pack(side="left")
    dg_flag_lbls.append(dot)
dg_fw = tk.Label(dg_l, text="firmware: —", bg=SURFACE, fg=FAINT, font=F_SM)
dg_fw.pack(anchor="w", pady=(8, 0))

section(dg_l, "Push direction  (Ps±1)")
dir_var = tk.IntVar(value=1)
dr = tk.Frame(dg_l, bg=SURFACE); dr.pack(fill="x", pady=(0, 6))


def set_dir():
    dev_send(f"Ps{dir_var.get()}")


for _txt, _v in (("+1  (CW)", 1), ("−1  (CCW)", -1)):
    tk.Radiobutton(dr, text=_txt, variable=dir_var, value=_v, command=set_dir,
                   bg=SURFACE, fg=TEXT, selectcolor=FIELD, font=F_LBL,
                   activebackground=SURFACE, highlightthickness=0).pack(side="left", padx=(0, 14))
tk.Label(dg_l, text="Jog, watch the grams. If the arm moves AWAY\nfrom the cell, flip this sign, then re-run the test.",
         bg=SURFACE, fg=FAINT, font=F_SM, justify="left").pack(anchor="w", pady=(0, 8))

section(dg_l, "Manual jog")
dg_jog_i = entry_row(dg_l, "Jog current (A)", 0.5)
dg_jog_t = entry_row(dg_l, "Jog time (s)", 2.0)
dg_lever = entry_row(dg_l, "Loadcell lever arm (m)", 0.10)


def _baseline():
    """Zero the load cell with NO current applied. Absolute grams are
    meaningless here — the arm's own weight is already sitting on the cell, so
    only the CHANGE caused by current tells you anything."""
    dev_send("O0")
    time.sleep(0.8)
    return lc_latest(0.6)


def dg_jog():
    try:
        i = float(dg_jog_i.get()); t = max(0.2, min(20.0, float(dg_jog_t.get())))
    except ValueError:
        dg_set("Check the numbers", AMBER); return

    def run():
        dg_set("Zeroing (no current)…", BLUE)
        base = _baseline()
        t_start = time.time()
        dev_send(f"C{i:.3f}")
        dg_set(f"Jogging at {i:.2f} A for {t:.1f} s…", BLUE)
        time.sleep(t)
        m, _ = iq_avg(min(t, 1.0))
        g = lc_latest(0.6)
        dev_send("C0"); stop_all()
        peak = max([abs(r) for (ts, r) in rpm_hist if ts >= t_start] or [0.0])
        d = None if (g is None or base is None) else (g - base)
        txt = (f"Iq meas {0.0 if m is None else m:+.3f} A · peak {peak:.0f} rpm · "
               f"Δ loadcell {'--' if d is None else f'{d:+.1f} g'} "
               f"(from {'--' if base is None else f'{base:.1f}'} g)")
        if peak > 60 and (d is None or abs(d) < 5):
            root.after(0, lambda: dg_set(txt + "  — shaft was FREE (spun up, no force). "
                                         "Load the arm against the cell and jog again.", AMBER))
        elif d is not None and d < -3:
            root.after(0, lambda: dg_set(txt + "  — NEGATIVE: current is LIFTING the arm OFF "
                                         "the cell, not pressing it. Flip the direction above.", RED))
        else:
            root.after(0, lambda: dg_set(txt, GREEN))
    threading.Thread(target=run, daemon=True).start()


def dg_sweep():
    """Direction + linearity sweep. Torque must be PROPORTIONAL to current;
    this is the one measurement that distinguishes the three ways it can fail:
      falling with current      -> the push direction is inverted (lift-off)
      flat / saturating         -> the arm is not really loaded, or Iq is clamped
      rising but not linear     -> the dq frame or the current-loop tuning is off
    Everything downstream (Kt, capstan efficiency) is meaningless until this
    comes out clean, so it is worth the 15 seconds."""
    try:
        lever = float(dg_lever.get())
    except ValueError:
        dg_set("Check the lever arm", AMBER); return

    def run():
        if lc["ser"] is None:
            root.after(0, lambda: dg_set("Connect the load cell first", RED)); return
        dg_set("Sweep: zeroing (no current)…", BLUE)
        base = _baseline()
        if base is None:
            root.after(0, lambda: dg_set("No load-cell data", RED)); return
        pts = []
        for i in (0.2, 0.5, 1.0):
            dev_send(f"C{i:.3f}")
            root.after(0, lambda i=i: dg_set(f"Sweep: {i:.2f} A…", BLUE))
            time.sleep(1.8)
            g = lc_latest(0.6)
            m, _ = iq_avg(1.0)
            pts.append((i, None if g is None else g - base, m))
        dev_send("C0"); stop_all()

        rows = " · ".join(f"{i:.1f}A→{'--' if d is None else f'{d:+.0f}g'}" for i, d, _ in pts)
        ds = [d for _, d, _ in pts if d is not None]
        if len(ds) < 3:
            root.after(0, lambda: dg_set("Sweep incomplete — load-cell dropouts. " + rows, AMBER))
            return
        if ds[-1] < ds[0] - 3:
            msg = ("FALLING with current → the motor is UNLOADING the cell. "
                   "Flip the direction above (Ps) and sweep again.")
            col = RED
        elif max(abs(x) for x in ds) < 5:
            msg = ("No force at any current → the arm is not actually loaded "
                   "against the cell, or Iq is being clamped. Check Pi and the fixture.")
            col = RED
        elif ds[-1] < 2.5 * ds[0]:
            msg = ("Rising but NOT proportional (5x the current should give ~5x the force) → "
                   "suspect the dq frame or the current-loop tuning. Check id on the right: "
                   "if |id| is anywhere near |iq| the commutation angle is wrong.")
            col = AMBER
        else:
            m_last = pts[-1][2]
            kt = (ds[-1] * 1e-3 * G_ACC * lever / abs(m_last)) * 1000 if m_last else None
            msg = f"Proportional — good. Implied Kt ≈ {kt:.0f} mNm/A" if kt else "Proportional — good."
            col = GREEN
        root.after(0, lambda: dg_set(rows + "   " + msg, col))
    threading.Thread(target=run, daemon=True).start()


jb = tk.Frame(dg_l, bg=SURFACE); jb.pack(fill="x", pady=(4, 2))
btn(jb, "↻ JOG", BLUE, "white", dg_jog, width=8).pack(side="left", padx=(0, 6))
btn(jb, "■ STOP", RED, "white", stop_all, width=8).pack(side="left")
btn(dg_l, "📈 DIRECTION + LINEARITY SWEEP  (0.2 / 0.5 / 1.0 A)", FIELD, BLUE,
    dg_sweep).pack(fill="x", pady=(6, 0))

section(dg_l, "Current-sense self-test")
tk.Label(dg_l, text="Block the shaft (arm resting on the cell),\nthen run. Firmware pushes 1.0 A for 1 s and\nreports commanded vs measured.",
         bg=SURFACE, fg=FAINT, font=F_SM, justify="left").pack(anchor="w", pady=(0, 6))
btn(dg_l, "✓ RUN SELF-TEST (Z)", FIELD, GREEN, lambda: dev_send("Z")).pack(fill="x")
btn(dg_l, "ℹ Status dump (L)", FIELD, BLUE, lambda: dev_send("L")).pack(fill="x", pady=(6, 0))
dg_set = mkstatus(dg_l)

dg_m_o, dg_m = card(dg_fr); dg_m_o.pack(side="left", fill="both", expand=True, padx=(0, 14))
section(dg_m, "Serial console  ·  everything the firmware says")
dg_txt = tk.Text(dg_m, bg="#0f1419", fg="#c8d3e0", insertbackground="#c8d3e0",
                 font=("Consolas", 11), relief="flat", height=22, wrap="none")
dg_txt.pack(fill="both", expand=True)
dg_txt.tag_config("tx", foreground="#7dd3fc")
dg_txt.tag_config("rx", foreground="#c8d3e0")
dg_txt.tag_config("err", foreground="#fca5a5")
dg_txt.tag_config("sys", foreground="#fcd34d")
dg_n = [0]


def dg_console_tick():
    with console_lock:
        n = console_seq[0]
        if n != dg_n[0]:
            rows = list(console)
            dg_n[0] = n
        else:
            rows = None
    if rows is not None:
        dg_txt.config(state="normal")
        dg_txt.delete("1.0", "end")
        for ts, kind, text in rows:
            dg_txt.insert("end", f"{ts} {'>' if kind == 'tx' else ' '} {text}\n", kind)
        dg_txt.see("end")
        dg_txt.config(state="disabled")
    root.after(300, dg_console_tick)


cmd_row = tk.Frame(dg_m, bg=SURFACE); cmd_row.pack(fill="x", pady=(8, 0))
tk.Label(cmd_row, text="send:", bg=SURFACE, fg=MUTED, font=F_LBL).pack(side="left", padx=(0, 8))
dg_cmd = tk.Entry(cmd_row, bg=FIELD, fg=TEXT, insertbackground=TEXT, relief="flat",
                  font=("Consolas", 13), highlightthickness=1,
                  highlightbackground=BORDER, highlightcolor=BLUE)
dg_cmd.pack(side="left", fill="x", expand=True, ipady=4)


def dg_send_cmd(_e=None):
    c = dg_cmd.get().strip()
    if c:
        dev_send(c)
        dg_cmd.delete(0, "end")


dg_cmd.bind("<Return>", dg_send_cmd)
tk.Button(cmd_row, text="Send", command=dg_send_cmd, bg=FIELD, fg=BLUE,
          relief="flat", bd=0, font=("Segoe UI", 11, "bold"), padx=12, pady=4,
          cursor="hand2", highlightthickness=0).pack(side="left", padx=(8, 0))
tk.Label(dg_m, text="e.g.  L   Z   C0.5   O0   Pi4   Ps-1   Pv20   Pm2   Pt0   MMS0001001   MMD10",
         bg=SURFACE, fg=FAINT, font=F_SM).pack(anchor="w", pady=(4, 0))

dg_r_o, dg_r = card(dg_fr); dg_r_o.pack(side="left", fill="y")
section(dg_r, "Live · commanded vs measured")
dg_iqc = big_value(dg_r, "Iq COMMANDED (A)", AMBER)
dg_iqm = big_value(dg_r, "Iq MEASURED (A)", BLUE)
dg_verdict = tk.Label(dg_r, text="", bg=SURFACE, fg=MUTED, font=F_LBL,
                      wraplength=280, justify="left")
dg_verdict.pack(pady=(10, 0))
dg_extra = tk.Label(dg_r, text="", bg=SURFACE, fg=FAINT, font=("Consolas", 12),
                    justify="left")
dg_extra.pack(anchor="w", pady=(10, 0))
add_tab("0 · Diagnostics", dg_fr)


def dg_tick():
    fl = T["flags"]
    idle = (T["state"] == 0)
    for i, (bit, _n) in enumerate(FLAG_BITS):
        if fl < 0:
            dg_flag_lbls[i].config(fg=FAINT)          # old 7-field firmware
        elif bit in (0x02, 0x04) and idle:
            # "motor enabled" and "driver powered" are SUPPOSED to be off in
            # IDLE — that is the true-freewheel design, not a fault. Grey, not
            # red, so a limp shaft never looks like a broken board.
            dg_flag_lbls[i].config(fg=FAINT)
        else:
            dg_flag_lbls[i].config(fg=GREEN if (fl & bit) else RED)
    dg_fw.config(text=f"firmware: {link['fw'] or '—'}   ({T['nfields']} telemetry fields)")
    dg_iqc.config(text=f"{T['iqc']:+.3f}")
    dg_iqm.config(text=f"{T['iq']:+.3f}")
    # the actual diagnosis, spelled out
    if not dev_alive():
        dg_verdict.config(text="No telemetry. Connect the driver port, or send D20.", fg=RED)
    elif fl >= 0 and not (fl & 0x01):
        dg_verdict.config(text="initFOC FAILED. The motor physically cannot move: check the AS5047P magnet, pole pairs and bus power.", fg=RED)
    elif fl >= 0 and not (fl & 0x10):
        dg_verdict.config(text="Vbus reading is out of range — phase voltage may be capped at 0. Set it with Pu24.", fg=RED)
    elif idle:
        dg_verdict.config(text="IDLE — bridge is open, shaft is free. Current reads exactly 0 by design; "
                               "sensing cannot be judged until a mode is entered. Jog to test.", fg=MUTED)
    elif abs(T["iqc"]) < 0.05:
        dg_verdict.config(text="Firmware is commanding ~0 A. Nothing is wrong with sensing yet — send a current (jog) first.", fg=MUTED)
    elif abs(T["iq"]) < 0.25 * abs(T["iqc"]):
        dg_verdict.config(text="Current is COMMANDED but not MEASURED. Shunt/ADC path or torque mode: try Pm1, check Pq, check M0_IB/M0_IC wiring.", fg=RED)
    elif abs(T["idq"]) > 0.5 * abs(T["iq"]) and abs(T["iq"]) > 0.2:
        # id should sit near zero: all current on the q axis is what makes
        # torque proportional to Iq. A large id means the dq frame is rotated
        # away from the rotor, so Kt per amp is neither constant nor correct.
        dg_verdict.config(text=f"|id| = {abs(T['idq']):.2f} A is large next to |iq| = {abs(T['iq']):.2f} A. "
                               "The commutation angle is off, so torque will NOT scale with current. "
                               "Suspect the current-sense phase mapping (skip_align) or the sensor zero angle.", fg=RED)
    else:
        dg_verdict.config(text="Command and measurement agree, id is small. If there is still no force, the push DIRECTION is wrong — flip Ps.", fg=GREEN)
    g = lc_latest(1.0)
    dg_extra.config(text=(f"state    {STATE_NAMES.get(T['state'], '?')}\n"
                          f"angle    {math.degrees(T['ang']):+8.1f} deg\n"
                          f"velocity {T['vel']:+8.2f} rad/s\n"
                          f"id meas  {T['idq']:+8.3f} A\n"
                          f"voltage q{T['vq']:+8.3f} V\n"
                          f"loadcell {'--' if g is None else f'{g:8.1f} g'}"))
    root.after(200, dg_tick)


# ═════════════ TAB 1 · KV back-EMF ═════════════════════════════
kv_fr = tk.Frame(body, bg=BG)
kv = dict(steps=[], idx=0, spinning=False, points=[])

kv_l_o, kv_l = card(kv_fr); kv_l_o.pack(side="left", fill="y", padx=(0, 14))
section(kv_l, "Test setup · DUT terminals OPEN")
kv_start = entry_row(kv_l, "Start speed (DUT rpm)", 300)
kv_end = entry_row(kv_l, "End speed (DUT rpm)", 1500)
kv_n = entry_row(kv_l, "Number of steps", 6)
kv_ratio = entry_row(kv_l, "Coupling ratio (DUT/drive)", 1.0)


def kv_build():
    try:
        lo = float(kv_start.get()); hi = float(kv_end.get()); n = max(2, int(kv_n.get()))
    except ValueError:
        kv_set("Check the numbers", AMBER); return
    kv["steps"] = [lo + (hi - lo) * i / (n - 1) for i in range(n)]
    kv["idx"] = 0; kv_step_ui()
    kv_set(f"{n} steps ready", GREEN)


btn(kv_l, "⚙  Build steps", FIELD, BLUE, kv_build).pack(pady=(6, 12), fill="x")
section(kv_l, "Step control")
sc = tk.Frame(kv_l, bg=SURFACE); sc.pack()


def kv_ratio_v():
    try:
        return max(0.01, float(kv_ratio.get()))
    except ValueError:
        return 1.0


def kv_send():
    dut = kv["steps"][kv["idx"]]
    dev_send(f"V{dut / kv_ratio_v() * 2 * math.pi / 60:.2f}")
    kv_set(f"Step {kv['idx']+1}/{len(kv['steps'])}: {dut:.0f} rpm", BLUE)


def kv_move(d):
    if not kv["steps"]:
        return
    kv["idx"] = max(0, min(len(kv["steps"]) - 1, kv["idx"] + d))
    kv_step_ui()
    if kv["spinning"]:
        kv_send()


def kv_spin():
    if not kv["steps"]:
        kv_build()
    kv["spinning"] = True; kv_send()


def kv_stop():
    kv["spinning"] = False; dev_send("V0"); stop_all()
    kv_set("Stopped — shaft released", RED)


btn(sc, "◀", FIELD, TEXT, lambda: kv_move(-1), width=3).pack(side="left", padx=3)
kv_lbl_step = tk.Label(sc, text="—", bg=SURFACE, fg=TEXT, font=("Segoe UI", 16, "bold"), width=7)
kv_lbl_step.pack(side="left")
btn(sc, "▶", FIELD, TEXT, lambda: kv_move(+1), width=3).pack(side="left", padx=3)
kv_lbl_target = tk.Label(kv_l, text="—", bg=SURFACE, fg=AMBER, font=("Consolas", 28, "bold"))
kv_lbl_target.pack(pady=(6, 0))
tk.Label(kv_l, text="target rpm (DUT)", bg=SURFACE, fg=FAINT, font=F_SM).pack()


def kv_step_ui():
    kv_lbl_step.config(text=f"{kv['idx']+1} / {len(kv['steps'])}" if kv["steps"] else "—")
    kv_lbl_target.config(text=f"{kv['steps'][kv['idx']]:.0f}" if kv["steps"] else "—")


bb = tk.Frame(kv_l, bg=SURFACE); bb.pack(pady=(10, 2))
btn(bb, "▶ SPIN", GREEN, "white", kv_spin, width=8).pack(side="left", padx=(0, 6))
btn(bb, "■ STOP", RED, "white", kv_stop, width=8).pack(side="left")
kv_set = mkstatus(kv_l)

kv_m_o, kv_m = card(kv_fr); kv_m_o.pack(side="left", fill="both", expand=True, padx=(0, 14))
section(kv_m, "Live speed")
kv_rpm = big_value(kv_m, "DUT rpm (measured)")
kv_steady = tk.Label(kv_m, text="", bg=SURFACE, fg=FAINT, font=("Segoe UI", 14, "bold"))
kv_steady.pack(pady=(4, 8))
kv_chart = tk.Canvas(kv_m, width=560, height=240, bg=SURFACE, highlightthickness=0)
kv_chart.pack(pady=4, fill="x")

kv_r_o, kv_r = card(kv_fr); kv_r_o.pack(side="left", fill="y")
section(kv_r, "Log a point · back-EMF from multimeter")
vf = tk.Frame(kv_r, bg=SURFACE); vf.pack(fill="x")
kv_volt = tk.Entry(vf, bg=FIELD, fg=AMBER, insertbackground=TEXT, relief="flat",
                   font=("Consolas", 18, "bold"), width=8, justify="center",
                   highlightthickness=1, highlightbackground=BORDER, highlightcolor=BLUE)
kv_volt.pack(side="left", ipady=5)
tk.Label(vf, text="V", bg=SURFACE, fg=MUTED, font=F_LBL).pack(side="left", padx=(6, 10))


def kv_steady_rpm():
    now = time.time()
    return robust_mean([r for (t, r) in rpm_hist if now - t <= 1.0])


def kv_log():
    try:
        v = float(kv_volt.get())
    except ValueError:
        kv_set("Type the voltage first", AMBER); return
    m, sd = kv_steady_rpm()
    if m is None:
        kv_set("No telemetry yet", AMBER); return
    dut = m * kv_ratio_v()
    tgt = kv["steps"][kv["idx"]] if kv["steps"] else dut
    kv["points"].append((tgt, dut, v))
    kv_table.insert("", "end", values=(f"{tgt:.0f}", f"{dut:.0f}", f"{v:.3f}"))
    kv_volt.delete(0, "end"); kv_fit()


def kv_undo():
    if kv["points"]:
        kv["points"].pop(); kv_table.delete(kv_table.get_children()[-1]); kv_fit()


btn(vf, "+ Log point", BLUE, "white", kv_log).pack(side="left")
kv_volt.bind("<Return>", lambda e: kv_log())
kv_table = mktable(kv_r, [("t", "target rpm", 100), ("m", "measured rpm", 120), ("v", "back-EMF V", 105)])
kb = tk.Frame(kv_r, bg=SURFACE); kb.pack(pady=(0, 10))


def kv_export():
    if not kv["points"]:
        kv_set("Nothing to save", AMBER); return
    path = log_path("kv-backemf")
    if not path:
        kv_set("Enter the motor serial number first", RED); return
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["target_rpm", "measured_rpm", "backemf_V"])
        for r in kv["points"]:
            w.writerow([f"{r[0]:.1f}", f"{r[1]:.1f}", f"{r[2]:.4f}"])
        w.writerow([]); w.writerow(["kv_rpm_per_V", kv_res.get("kv", "")])
    kv_set(f"Saved → {path}", GREEN)


btn(kb, "⌫ Undo", FIELD, MUTED, kv_undo).pack(side="left", padx=(0, 6))
btn(kb, "⤓ Save CSV", FIELD, GREEN, kv_export).pack(side="left")
section(kv_r, "Result · V = a·n + b → KV = 1/a")
rf = tk.Frame(kv_r, bg=SURFACE); rf.pack()
c1 = tk.Frame(rf, bg=SURFACE); c1.pack(side="left", padx=14)
kv_lbl_kv = tk.Label(c1, text="—", bg=SURFACE, fg=GREEN, font=("Consolas", 30, "bold"))
kv_lbl_kv.pack(); tk.Label(c1, text="KV [rpm/V]", bg=SURFACE, fg=FAINT, font=F_SM).pack()
c2 = tk.Frame(rf, bg=SURFACE); c2.pack(side="left", padx=14)
kv_lbl_kt = tk.Label(c2, text="—", bg=SURFACE, fg=GREEN, font=("Consolas", 30, "bold"))
kv_lbl_kt.pack(); tk.Label(c2, text="Kt [mNm/A]", bg=SURFACE, fg=FAINT, font=F_SM).pack()
kv_lbl_r2 = tk.Label(kv_r, text="log ≥ 2 points", bg=SURFACE, fg=FAINT, font=F_LBL)
kv_lbl_r2.pack(pady=(8, 0))
kv_res = {}


def kv_fit():
    if len(kv["points"]) < 2:
        kv_lbl_kv.config(text="—"); kv_lbl_kt.config(text="—")
        kv_lbl_r2.config(text="log ≥ 2 points"); return
    fit = linfit([p[1] for p in kv["points"]], [p[2] for p in kv["points"]])
    if fit is None or fit[0] <= 1e-9:
        kv_lbl_r2.config(text="bad slope — check points"); return
    a, b, r2 = fit
    kvv = 1.0 / a
    kv_res["kv"] = f"{kvv:.2f}"
    kv_lbl_kv.config(text=f"{kvv:.1f}")
    kv_lbl_kt.config(text=f"{9.55/kvv*1000:.1f}")
    kv_lbl_r2.config(text=f"R² = {r2:.4f} · offset {b*1000:+.0f} mV · {len(kv['points'])} pts")


add_tab("1 · KV · Back-EMF", kv_fr)

# ═════════════ TAB 2 · KT add-weight ═══════════════════════════
w_fr = tk.Frame(body, bg=BG)
wt = dict(rows=[], holding=False)

w_l_o, w_l = card(w_fr); w_l_o.pack(side="left", fill="y", padx=(0, 14))
section(w_l, "Setup · rotate arm HORIZONTAL first (shaft is free in IDLE)")
w_len = entry_row(w_l, "Arm length L to weights (m)", 0.10)
w_arm = entry_row(w_l, "Arm effective weight at tip (g)", 25.0)
w_iqmx = entry_row(w_l, "Max Iq protection (A)", 4.0)


def w_hold():
    try:
        dev_send(f"Pi{float(w_iqmx.get()):.2f}")
    except ValueError:
        pass
    dev_send("H")
    wt["holding"] = True
    w_set("HOLDING — add a weight, enter grams, Record", GREEN)


def w_stop():
    wt["holding"] = False
    stop_all()
    w_set("Released — shaft free", RED)


hb2 = tk.Frame(w_l, bg=SURFACE); hb2.pack(pady=(8, 2))
btn(hb2, "⚓ HOLD", GREEN, "white", w_hold, width=9).pack(side="left", padx=(0, 6))
btn(hb2, "■ RELEASE", RED, "white", w_stop, width=10).pack(side="left")
section(w_l, "Record a step")
w_add = entry_row(w_l, "Total added weight on arm (g)", 0.0)


def w_record():
    if not wt["holding"]:
        w_set("HOLD first", AMBER); return
    try:
        add_g = float(w_add.get()); L = float(w_len.get()); arm_g = float(w_arm.get())
    except ValueError:
        w_set("Check the numbers", AMBER); return
    if T["state"] != 2:
        w_set(f"Firmware is not HOLDING (state = {STATE_NAMES.get(T['state'],'?')}). "
              "Press HOLD again and watch the Diagnostics console.", RED)
        return
    m, sd = iq_avg(1.0)
    if m is None:
        w_set("No telemetry — connect first", AMBER); return
    tau = (add_g + arm_g) * 1e-3 * G_ACC * L
    wt["rows"].append((add_g, add_g + arm_g, tau, abs(m), sd or 0.0))
    w_table.insert("", "end", values=(f"{add_g:.0f}", f"{tau*1000:.1f}", f"{abs(m):.3f}", f"±{(sd or 0)*1000:.0f}m"))
    w_fit()
    w_set(f"Recorded: {tau*1000:.1f} mNm at {abs(m):.3f} A", GREEN)


btn(w_l, "➕ Record value", BLUE, "white", w_record).pack(pady=(4, 8), fill="x")


def w_end():
    if not wt["rows"]:
        w_set("No rows to save", AMBER); return
    path = log_path("kt-weight")
    if not path:
        w_set("Enter the motor serial number first", RED); return
    with open(path, "w", newline="") as f:
        wcsv = csv.writer(f)
        wcsv.writerow(["added_g", "total_g", "tau_Nm", "iq_A", "iq_std_A"])
        for r in wt["rows"]:
            wcsv.writerow([f"{r[0]:.1f}", f"{r[1]:.1f}", f"{r[2]:.5f}", f"{r[3]:.4f}", f"{r[4]:.4f}"])
        wcsv.writerow([]); wcsv.writerow(["kt_mNm_per_A", w_res.get("kt", "")])
    w_stop()
    w_set(f"Saved {len(wt['rows'])} rows → {path}", GREEN)


btn(w_l, "⏹ END — save log & release", FIELD, GREEN, w_end).pack(fill="x")
w_set = mkstatus(w_l)

w_m_o, w_m = card(w_fr); w_m_o.pack(side="left", fill="y", padx=(0, 14))
section(w_m, "Live · holding current")
w_iq = big_value(w_m, "Iq (A, 1 s robust average)", BLUE)
w_state = tk.Label(w_m, text="—", bg=SURFACE, fg=MUTED, font=F_MONO)
w_state.pack(pady=(8, 0))
w_ang = tk.Label(w_m, text="", bg=SURFACE, fg=FAINT, font=F_MONO)
w_ang.pack(pady=(4, 0))

w_r_o, w_r = card(w_fr); w_r_o.pack(side="left", fill="y")
section(w_r, "Steps")
w_table = mktable(w_r, [("g", "added g", 80), ("t", "τ mNm", 90),
                        ("i", "Iq A", 90), ("s", "std", 70)], height=10)
section(w_r, "Result · τ = Kt·Iq + τf")
w_lbl_kt = tk.Label(w_r, text="—", bg=SURFACE, fg=GREEN, font=("Consolas", 30, "bold"))
w_lbl_kt.pack()
tk.Label(w_r, text="Kt [mNm/A]  (motor)", bg=SURFACE, fg=FAINT, font=F_SM).pack()
w_lbl_r2 = tk.Label(w_r, text="record ≥ 2 steps", bg=SURFACE, fg=FAINT, font=F_LBL)
w_lbl_r2.pack(pady=(6, 0))
w_res = {}


def w_fit():
    if len(wt["rows"]) < 2:
        return
    fit = linfit([r[3] for r in wt["rows"]], [r[2] for r in wt["rows"]])
    if fit is None:
        return
    a, b, r2 = fit
    w_res["kt"] = f"{a*1000:.2f}"
    w_lbl_kt.config(text=f"{a*1000:.1f}")
    w_lbl_r2.config(text=f"R² = {r2:.4f} · friction {b*1000:+.1f} mNm · {len(wt['rows'])} pts")


add_tab("2 · KT · Weights", w_fr)


# ═════════════ step-test engine (tabs 3 & 5) ═══════════════════
def build_step_tab(exp_name, title_note, gear_default, with_eff):
    fr = tk.Frame(body, bg=BG)
    st = dict(rows=[], run=False, marks=[])

    l_o, l = card(fr); l_o.pack(side="left", fill="y", padx=(0, 14))
    section(l, f"Setup · {title_note}")
    e_i0 = entry_row(l, "Iq start (A)", 0.5)
    e_i1 = entry_row(l, "Iq end (A)", 3.0)
    e_ns = entry_row(l, "Number of steps", 6)
    e_ts = entry_row(l, "Step time (s)", 2.0)
    e_st = entry_row(l, "Settle discard (s)", 0.7)
    e_en = entry_row(l, "Engage current (A)", 0.30)
    e_rp = entry_row(l, "Current ramp (A/s)", 2.0)
    # [g2-B] contact detection replaces the old blind fixed-time engage
    e_cg = entry_row(l, "Contact threshold (g)", 15.0)
    e_ct = entry_row(l, "Contact timeout (s)", 15.0)
    e_lv = entry_row(l, "Loadcell lever arm (m)", 0.10)
    e_gr = entry_row(l, "Gear ratio (out/motor)", gear_default)
    e_mk = entry_row(l, "Motor Kt for efficiency (mNm/A)", 83.7) if with_eff else None
    set_ = mkstatus(l)

    def wait_for_contact(zero_g, thresh_g, timeout_s):
        """Poll the load cell until grams rise `thresh_g` above the zero
        reference. Returns True on contact. v1 slept a fixed ~2 s and simply
        ASSUMED contact, which is why every step could record 0 g in silence."""
        t_end = time.time() + timeout_s
        while time.time() < t_end and st["run"]:
            time.sleep(0.1)
            g = lc_latest(0.5)
            if g is not None and (g - zero_g) >= thresh_g:
                return True
        return False

    def runner():
        try:
            i0 = float(e_i0.get()); i1 = float(e_i1.get()); n = max(2, int(e_ns.get()))
            ts = max(0.8, float(e_ts.get())); settle = min(ts - 0.3, max(0.1, float(e_st.get())))
            lever = float(e_lv.get())
            i_eng = max(0.02, float(e_en.get())); ramp = max(0.1, float(e_rp.get()))
            thresh_g = max(1.0, float(e_cg.get())); c_to = max(2.0, float(e_ct.get()))
        except ValueError:
            set_("Check the numbers", AMBER); st["run"] = False; return
        if lc["ser"] is None:
            set_("Connect the loadcell serial first", RED); st["run"] = False; return
        if not dev_alive():
            set_("No telemetry from the driver — connect it first", RED); st["run"] = False; return
        if T["flags"] > 0 and not (T["flags"] & 0x01):
            set_("Firmware reports initFOC FAILED — the motor cannot move. See Diagnostics.", RED)
            st["run"] = False; return

        i0 = max(i0, i_eng)                          # steps never drop below engage
        st["rows"].clear(); st["marks"].clear()
        for it in table.get_children():
            table.delete(it)

        set_("Taring — arm should be RESTING on the loadcell", BLUE)
        dev_send(f"Pr{ramp:.2f}")
        t0 = time.time(); time.sleep(0.8)
        z, _ = robust_mean([g for (_, g, _) in lc_window(t0, time.time())])
        z = z or 0.0

        # ENGAGE: make first contact ONCE, gently — then never leave contact
        set_(f"Engaging at {i_eng:.2f} A — waiting for contact…", BLUE)
        dev_send(f"C{i_eng:.3f}")
        st["marks"].append(time.time())
        if not wait_for_contact(z, thresh_g, c_to):
            dev_send("C0"); stop_all(); st["run"] = False
            m, _ = iq_avg(1.0)
            hint = ("the current sense reads ~0 as well — check the Diagnostics tab"
                    if (m is None or abs(m) < 0.1) else
                    "current IS flowing, so the arm is very likely pushing the WRONG WAY "
                    "— flip the direction (Ps) on the Diagnostics tab")
            root.after(0, lambda: set_(
                f"NO CONTACT after {c_to:.0f} s at {i_eng:.2f} A: {hint}.", RED))
            return
        set_("Contact — running steps", GREEN)

        currents = [i0 + (i1 - i0) * i / (n - 1) for i in range(n)]
        prev = i_eng
        for k, iq in enumerate(currents):
            if not st["run"]:
                break
            dev_send(f"C{iq:.3f}")
            t_step = time.time(); st["marks"].append(t_step)
            settle_eff = max(settle, abs(iq - prev) / ramp + 0.4)
            settle_eff = min(settle_eff, ts - 0.2)
            prev = iq
            time.sleep(settle_eff)                   # discard: force not settled
            t_use0 = time.time()
            time.sleep(max(0.05, ts - settle_eff))
            samples = lc_window(t_use0, time.time())
            gm, gs = robust_mean([g for (_, g, _) in samples])
            im, _ = iq_avg(ts - settle)
            used_cmd = False
            if im is None or (abs(im) < 0.25 * iq and iq >= 0.1):
                # measured current path dead — fit with the commanded value
                icm, _ = iqc_avg(ts - settle)
                im = icm if icm is not None else iq
                used_cmd = True
                root.after(0, lambda: set_(
                    "Current sense reads ~0 — using COMMANDED Iq for the fit. "
                    "Run the self-test (Z) on the Diagnostics tab.", AMBER))
            if gm is None:
                root.after(0, lambda k=k: set_(f"Step {k+1}: no loadcell data", RED))
                continue
            grams = gm - z
            tau = grams * 1e-3 * G_ACC * lever
            st["rows"].append((iq, abs(im or iq), grams, gs or 0, tau, used_cmd))
            root.after(0, lambda r=st["rows"][-1]:
                       table.insert("", "end", values=(f"{r[0]:.2f}", f"{r[1]:.3f}",
                                    f"{r[2]:.1f}", f"±{r[3]:.1f}", f"{r[4]*1000:.1f}")))
            root.after(0, fit)
            if not used_cmd:
                root.after(0, lambda k=k, n=n: set_(f"Step {k+1}/{n} done", BLUE))
        dev_send("C0"); stop_all()
        st["run"] = False
        root.after(0, save)

    def start():
        if st["run"]:
            return
        st["run"] = True
        threading.Thread(target=runner, daemon=True).start()

    def stop():
        st["run"] = False
        dev_send("C0"); stop_all()
        set_("Stopped", RED)

    def fit():
        if len(st["rows"]) < 2:
            return
        f = linfit([r[1] for r in st["rows"]], [r[4] for r in st["rows"]])
        if f is None:
            return
        a, b, r2 = f
        lbl_kt.config(text=f"{a*1000:.1f}")
        extra = f"R² = {r2:.4f} · offset {b*1000:+.1f} mNm"
        if any(r[5] for r in st["rows"]):
            extra += " · ⚠ COMMANDED Iq used"
        if with_eff and e_mk is not None:
            try:
                ktm = float(e_mk.get()) * 1e-3
                N = float(e_gr.get())
                eff = a / (ktm * N) * 100.0
                extra += f" · efficiency {eff:.1f}%"
            except ValueError:
                pass
        lbl_r2.config(text=extra)

    def save():
        if not st["rows"]:
            return
        path = log_path(exp_name)
        if not path:
            set_("Enter the motor serial number first", RED); return
        with open(path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["iq_cmd_A", "iq_meas_A", "grams", "grams_std", "tau_Nm", "iq_from_command"])
            for r in st["rows"]:
                w.writerow([f"{r[0]:.3f}", f"{r[1]:.4f}", f"{r[2]:.2f}",
                            f"{r[3]:.2f}", f"{r[4]:.5f}", int(r[5])])
            w.writerow([]); w.writerow(["kt_out_mNm_per_A", lbl_kt.cget("text")])
        set_(f"Done — saved → {path}", GREEN)

    bb = tk.Frame(l, bg=SURFACE); bb.pack(pady=(8, 2))
    btn(bb, "▶ RUN", GREEN, "white", start, width=8).pack(side="left", padx=(0, 6))
    btn(bb, "■ STOP", RED, "white", stop, width=8).pack(side="left")

    m_o, m = card(fr); m_o.pack(side="left", fill="both", expand=True, padx=(0, 14))
    section(m, "Loadcell force (blue) · measured Iq (purple, own scale) · dashed = steps")
    cv = tk.Canvas(m, width=620, height=300, bg=SURFACE, highlightthickness=0)
    cv.pack(fill="both", expand=True, pady=4)
    live = tk.Label(m, text="", bg=SURFACE, fg=MUTED, font=F_MONO)
    live.pack()

    def tick():
        alive = sense_alive()
        y2 = list(iq_hist) if alive else list(iqc_hist)
        lab = ("grams (blue) · Iq measured (purple)" if alive else
               "grams (blue) · Iq COMMANDED (purple) — sense reads 0!")
        draw_ts(cv, [(t, g) for (t, g, _) in lc_buf], BLUE, lab,
                marks=st["marks"], y2=y2)
        s = lc_buf[-1] if lc_buf else None
        base = f"loadcell {s[1]:.1f} g   " if s else "no loadcell data   "
        live.config(text=base + f"Iq meas {T['iq']:+.2f} / cmd {T['iqc']:+.2f} A   "
                                f"[{STATE_NAMES.get(T['state'], '?')}]",
                    fg=MUTED if alive else RED)
        root.after(150, tick)

    tick()

    r_o, r = card(fr); r_o.pack(side="left", fill="y")
    section(r, "Steps")
    table = mktable(r, [("c", "Iq cmd", 70), ("i", "Iq meas", 80), ("g", "grams", 80),
                        ("s", "std", 65), ("t", "τ mNm", 85)], height=10)
    section(r, "Result · τ = Kt·Iq")
    lbl_kt = tk.Label(r, text="—", bg=SURFACE, fg=GREEN, font=("Consolas", 30, "bold"))
    lbl_kt.pack()
    tk.Label(r, text=("Kt_out [mNm/A] (after capstan)" if with_eff else "Kt [mNm/A] (motor)"),
             bg=SURFACE, fg=FAINT, font=F_SM).pack()
    lbl_r2 = tk.Label(r, text="run ≥ 2 steps", bg=SURFACE, fg=FAINT, font=F_LBL)
    lbl_r2.pack(pady=(6, 0))
    return fr


add_tab("3 · KT · Loadcell", build_step_tab("kt-loadcell", "motor direct → loadcell", 1.0, False))

# ═════════════ TAB 4 · Heat over force ═════════════════════════
h_fr = tk.Frame(body, bg=BG)
ht = dict(run=False, rows=[], t0=0.0, file=None, wr=None, marks=[], overt=False)

h_l_o, h_l = card(h_fr); h_l_o.pack(side="left", fill="y", padx=(0, 14))
section(h_l, "Setup · continuous-current thermal test")
h_iq = entry_row(h_l, "Test Iq (A)", 2.0)
h_lim = entry_row(h_l, "High-temp protection (°C)", 80.0)
h_lv = entry_row(h_l, "Loadcell lever arm (m)", 0.10)
h_set = mkstatus(h_l)


def h_runner():
    try:
        iq = float(h_iq.get()); tlim = float(h_lim.get()); lever = float(h_lv.get())
    except ValueError:
        h_set("Check the numbers", AMBER); ht["run"] = False; return
    if lc["ser"] is None:
        h_set("Connect the loadcell/temp serial first", RED); ht["run"] = False; return
    if not dev_alive():
        h_set("No telemetry from the driver — connect it first", RED); ht["run"] = False; return
    path = log_path("heat-force")
    if not path:
        h_set("Enter the motor serial number first", RED); ht["run"] = False; return
    ht["rows"].clear(); ht["marks"] = [time.time()]
    ht["file"] = open(path, "w", newline="")
    ht["wr"] = csv.writer(ht["file"])
    ht["wr"].writerow(["t_s", "iq_meas_A", "grams", "tau_Nm", "temp_C", "note"])
    dev_send(f"C{iq:.3f}")
    ht["t0"] = time.time()
    h_set(f"Running at {iq:.2f} A — logging 1 Hz → {os.path.basename(path)}", BLUE)
    while ht["run"]:
        time.sleep(1.0)
        now = time.time()
        win = lc_window(now - 1.0, now)
        gm, _ = robust_mean([g for (_, g, _) in win])
        temps = [tp for (_, _, tp) in win if tp is not None]
        tm, _ = robust_mean(temps) if temps else (None, None)
        im, _ = iq_avg(1.0)
        tau = (gm or 0.0) * 1e-3 * G_ACC * lever
        note = ""
        if tm is not None and tm >= tlim:
            note = "OVERTEMP-STOP"
        # a watchdog trip or fault mid-run must not be logged as valid data
        if T["state"] != 3:
            note = note or "FIRMWARE-LEFT-CURRENT-MODE"
        row = (now - ht["t0"], abs(im or iq), gm or 0.0, tau, tm)
        ht["rows"].append(row)
        ht["wr"].writerow([f"{row[0]:.1f}", f"{row[1]:.3f}", f"{row[2]:.1f}",
                           f"{row[3]:.5f}", "" if tm is None else f"{tm:.1f}", note])
        ht["file"].flush()
        root.after(0, lambda r=row: h_live_row(r))
        if note == "OVERTEMP-STOP":
            ht["overt"] = True
            root.after(0, lambda tm=tm: h_set(
                f"OVERTEMP {tm:.1f}°C ≥ {tlim:.0f}°C — stopped, log saved", RED))
            break
        if note == "FIRMWARE-LEFT-CURRENT-MODE":
            ht["overt"] = True
            root.after(0, lambda: h_set(
                "Firmware left CURRENT mode mid-test (watchdog or fault) — "
                "stopped. See the Diagnostics console.", RED))
            break
    dev_send("C0"); stop_all()
    ht["run"] = False
    try:
        ht["file"].close()
    except Exception:
        pass
    if not ht["overt"]:
        root.after(0, lambda: h_set(f"Saved → {path}", GREEN))
    ht["overt"] = False


def h_start():
    if ht["run"]:
        return
    ht["run"] = True
    threading.Thread(target=h_runner, daemon=True).start()


def h_stop():
    ht["run"] = False


hb3 = tk.Frame(h_l, bg=SURFACE); hb3.pack(pady=(8, 2))
btn(hb3, "▶ RUN", GREEN, "white", h_start, width=8).pack(side="left", padx=(0, 6))
btn(hb3, "■ STOP", RED, "white", h_stop, width=8).pack(side="left")
tk.Label(h_l, text="Goal: find the max Iq the motor holds\ncontinuously without overheating — that\nbecomes ExArMo's working current limit.",
         bg=SURFACE, fg=FAINT, font=F_SM, justify="left").pack(anchor="w", pady=(10, 0))

h_m_o, h_m = card(h_fr); h_m_o.pack(side="left", fill="both", expand=True, padx=(0, 14))
section(h_m, "Temperature (purple) · force (blue)")
h_cv = tk.Canvas(h_m, width=640, height=320, bg=SURFACE, highlightthickness=0)
h_cv.pack(fill="both", expand=True, pady=4)
h_live = tk.Label(h_m, text="", bg=SURFACE, fg=MUTED, font=F_MONO)
h_live.pack()


def h_tick():
    draw_ts(h_cv, [(t, g) for (t, g, _) in lc_buf], BLUE, "grams / °C",
            marks=ht["marks"], y2=[(t, tp) for (t, _, tp) in lc_buf if tp is not None])
    s = lc_buf[-1] if lc_buf else None
    if s:
        h_live.config(text=f"{s[1]:.1f} g   {('%.1f' % s[2]) if s[2] is not None else '--'} °C   Iq {T['iq']:+.2f} A")
    root.after(200, h_tick)


h_r_o, h_r = card(h_fr); h_r_o.pack(side="left", fill="y")
section(h_r, "Log (1 Hz)")
h_table = mktable(h_r, [("t", "t s", 60), ("i", "Iq A", 70), ("g", "grams", 75),
                        ("tau", "τ mNm", 80), ("T", "°C", 60)], height=14)


def h_live_row(r):
    h_table.insert("", "end", values=(f"{r[0]:.0f}", f"{r[1]:.2f}", f"{r[2]:.0f}",
                                      f"{r[3]*1000:.1f}", "--" if r[4] is None else f"{r[4]:.1f}"))
    kids = h_table.get_children()
    if kids:
        h_table.see(kids[-1])


add_tab("4 · Heat / Force", h_fr)

# ═════════════ TAB 5 · Capstan torque ══════════════════════════
add_tab("5 · Capstan · Torque", build_step_tab("capstan-torque",
        "motor → capstan → loadcell (output side)", 9.0, True))


# ═════════════ global live loops ═══════════════════════════════
def global_tick():
    m, sd = kv_steady_rpm()
    dut = (m or 0.0) * kv_ratio_v()
    kv_rpm.config(text=f"{dut:.0f}")
    if m is not None and kv["spinning"] and kv["steps"]:
        tol = max(5.0, 0.01 * abs(kv["steps"][kv["idx"]]))
        kv_steady.config(text="● STEADY — read the meter" if (sd or 99) < tol else "● settling…",
                         fg=GREEN if (sd or 99) < tol else AMBER)
    else:
        kv_steady.config(text="")
    kvdata = [(t, r * kv_ratio_v()) for (t, r) in rpm_hist]
    draw_ts(kv_chart, kvdata, BLUE, "rpm")
    m2, _ = iq_avg(1.0)
    w_iq.config(text=f"{abs(m2):.3f}" if m2 is not None else "—")
    w_state.config(text=STATE_NAMES.get(T["state"], "?"),
                   fg=GREEN if T["state"] == 2 else MUTED)
    w_ang.config(text=f"shaft {math.degrees(T['ang']):+.1f}°   cmd {T['iqc']:+.2f} A")
    root.after(120, global_tick)


show_tab(0)
foot_tick()
dg_tick()
dg_console_tick()
global_tick()
threading.Thread(target=dev_reader, daemon=True).start()
threading.Thread(target=lc_reader, daemon=True).start()


def on_close():
    global running
    running = False
    ht["run"] = False
    stop_all()
    dev_disconnect(); lc_disconnect()
    root.destroy()


root.protocol("WM_DELETE_WINDOW", on_close)
root.mainloop()